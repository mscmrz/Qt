#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QRandomGenerator>
#include <QTimer>
#include <QStyle>
#include <QDesktopWidget>
#include <QDebug>
#include <QIcon>
#include <QGuiApplication>
#include "qcustomplot.h"

MainWindow::MainWindow(QWidget *parent):
  QMainWindow(parent)
  , ui(new Ui::MainWindow)
{
  ui->setupUi(this);


  setWindowTitle("Graphs");


  window()->setGeometry(QStyle::alignedRect(Qt::LeftToRight, Qt::AlignCenter, window()->size(), qApp->desktop()->availableGeometry()));

  time = new QTimer;
  ui->plot->legend->setVisible(true);
  ui->menubar->setVisible(true);

  ui->tabWidget->setTabText(0, "Set Point");
  ui->tabWidget->setTabText(1, "Set Range");
  ui->tabWidget->setTabText(2, "Setting");

  ui->plot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
  ui->plot->setSelectionRectMode(QCP::srmSelect);

  ui->plot->xAxis->setLabel("X");
  ui->plot->yAxis->setLabel("Y");
  ui->plot->xAxis2->setVisible(false);
  ui->plot->yAxis2->setVisible(false);

  QSharedPointer<QCPAxisTickerFixed>  x_fixedTicker(new QCPAxisTickerFixed);

  ui->plot->xAxis->setTicker(x_fixedTicker);
  x_fixedTicker->setTickStep(5.0);


  QSharedPointer<QCPAxisTickerFixed>  y_fixedTicker(new QCPAxisTickerFixed);

  ui->plot->yAxis->setTicker(y_fixedTicker);
  y_fixedTicker->setTickStep(10.0);

  ui->plot->xAxis->setRange(0, 100);
  ui->plot->yAxis->setRange(0, 100);
  ui->plot->xAxis2->setRange(0, 100);
  ui->plot->yAxis2->setRange(0, 100);

  ui->plot->xAxis->setSubTickLength(3);
  ui->plot->yAxis->setSubTickLength(3);

  ui->plot->xAxis->setTickLength(10);

  ui->plot->xAxis->setSubTickPen(QPen(QColor(255, 0, 0, 255)));
  ui->plot->yAxis->setSubTickPen(QPen(QColor(255, 0, 0, 255)));

  QCPScatterStyle::ScatterShape  Scatter_Items_Red   = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Red->currentIndex());
  QCPScatterStyle::ScatterShape  Scatter_Items_Green = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Green->currentIndex());
  QCPScatterStyle::ScatterShape  Scatter_Items_Blue  = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Blue->currentIndex());

  QCPGraph::LineStyle  LineStyle_Iteams_Red   = (QCPGraph::LineStyle)(ui->cbox_StyleLine_Red->currentIndex());
  QCPGraph::LineStyle  LineStyle_Iteams_Green = (QCPGraph::LineStyle)(ui->cbox_StyleLine_Green->currentIndex());
  QCPGraph::LineStyle  LineStyle_Iteams_Blue  = (QCPGraph::LineStyle)(ui->cbox_StyleLine_Blue->currentIndex());

  ui->plot->addGraph();
  ui->plot->graph(0)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Red, ui->cbox_Size_Red->value())));
  ui->plot->graph(0)->setLineStyle(LineStyle_Iteams_Red);
  ui->plot->graph(0)->setPen(QPen(QColor(255, 0, 0, 255)));
  ui->plot->graph(0)->setName("Red Node");

  ui->plot->addGraph();
  ui->plot->graph(1)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Green, ui->cbox_Size_Green->value())));
  ui->plot->graph(1)->setLineStyle(LineStyle_Iteams_Green);
  ui->plot->graph(1)->setPen(QPen(QColor(0, 255, 0, 255)));
  ui->plot->graph(1)->setName("Green Node");

  ui->plot->addGraph();
  ui->plot->graph(2)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Blue, ui->cbox_Size_Blue->value())));
  ui->plot->graph(2)->setLineStyle(LineStyle_Iteams_Blue);
  ui->plot->graph(2)->setPen(QPen(QColor(0, 0, 255, 255)));
  ui->plot->graph(2)->setName("Blue Node");

  ui->plot->addGraph();
  ui->plot->graph(3)->setName(" Near Node");

  ui->plot->legend->itemWithPlottable(ui->plot->graph(3))->setVisible(false);
  ui->plot->legend->setBrush(QColor(255, 255, 255, 150));

  ui->plot->setContextMenuPolicy(Qt::CustomContextMenu);


  disconnect(ui->plot, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(drag_mousePress(QMouseEvent*)));
  disconnect(ui->plot, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(drag_mouseMove(QMouseEvent*)));
  disconnect(ui->plot, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(drag_mouseRelease(QMouseEvent*)));

  disconnect(ui->plot, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(graph_Menu(QMouseEvent*)));

  connect(time, &QTimer::timeout, this, &MainWindow::autoAddPoint);
  connect(ui->plot, SIGNAL(mouseDoubleClick(QMouseEvent*)), this, SLOT(rezoom()));
  connect(ui->plot, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(xyGraph(QMouseEvent*)));

  disconnect(ui->plot, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(Zoom_Drag(QMouseEvent*)));
  // connect(ui->plot,SIGNAL(mouseRelease(QMouseEvent*)),this,SLOT(Zoom_Drag(QMouseEvent*)));


  ui->plot->plotLayout()->insertRow(0);
  ui->plot->plotLayout()->addElement(0, 0, new QCPTextElement(ui->plot, " Graphs Creator", QFont("sans", 11, QFont::Bold)));

  ui->chc_EnableMode->setChecked(false);
  ui->menubar->setVisible(false);
  ui->chb_Bound_Bandom->setChecked(false);

  ui->actionEnable_selection_mode->setChecked(ui->chc_EnableMode->checkState());

  ui->actionFix_bound_or_randome_range->setChecked(ui->chb_Bound_Bandom->checkState());

  num = ui->bx_Num_Node->value();

  if (num == 0) { ui->btn_Start_Stop->setEnabled(false); }

  color_scautter = 0;
  chb_auto       = true;
  ui->rb_RightClick_Editor->setChecked(true);

  ui->actionStart_stop->setIcon(QIcon(":/Icon/play.jpg"));
  ui->actionStart_stop->setText("Start");
  start_Stop = true;

  chb_ShowPoint = false;

  ui->rb_RightClick_Editor->setChecked(true);

  ui->plot->clearItems();


  // Create QCPAxisRect and QCPItemRect for all graphs

  xrec_Blue = new QCPAxisRect(ui->plot);
  irec_Blue = new QCPItemRect(ui->plot);

  xrec_Green = new QCPAxisRect(ui->plot);
  irec_Green = new QCPItemRect(ui->plot);

  xrec_Red = new QCPAxisRect(ui->plot);
  irec_Red = new QCPItemRect(ui->plot);

  // Create QCPAxisRect and QCPItemRect for all mouse event press, moev and relase

  xRectItem = new QCPItemRect(ui->plot);
  xRect     = new QCPAxisRect(ui->plot);


  // Shortcut key for play and stop in plot     F11

  play_stop = new QShortcut(ui->plot);
  play_stop->setKey(Qt::Key_F11);
  connect(play_stop, &QShortcut::activated, this, &MainWindow::on_btn_Start_Stop_toggled);
// connect(play_stop,SIGNAL(activated()),this,SLOT(on_btn_Start_Stop_toggled()),Qt::QueuedConnection);


  // Shortcut key for hide and show red graph     Ctrl+Shift+R

  hide_Red = new QShortcut(ui->plot);
  hide_Red->setKey(Qt::CTRL + Qt::SHIFT + Qt::Key_R);
  connect(hide_Red, &QShortcut::activated, this, &MainWindow::actionRed_Shortkey);

// connect(hide_Red,SIGNAL(activated()),this,SLOT(on_actionRed_Shortkey()),Qt::QueuedConnection);


  // Shortcut key for hide and show green graph     Ctrl+Shift+G

  hide_green = new QShortcut(ui->plot);
  hide_green->setKey(Qt::CTRL + Qt::SHIFT + Qt::Key_G);
  connect(hide_green, SIGNAL(activated()), this, SLOT(actionGreen_Shortkey()), Qt::QueuedConnection);


  // Shortcut key for hide and show blue graph     Ctrl+Shift+B

  hide_Blue = new QShortcut(ui->plot);
  hide_Blue->setKey(Qt::CTRL + Qt::SHIFT + Qt::Key_B);
  connect(hide_Blue, SIGNAL(activated()), this, SLOT(actionBlue_Shortkey()), Qt::QueuedConnection);

  // Shortcut key for hide and show all graphs     Ctrl+Shift+A

  hide_All = new QShortcut(ui->plot);
  hide_All->setKey(Qt::CTRL + Qt::SHIFT + Qt::Key_A);
  connect(hide_All, SIGNAL(activated()), this, SLOT(actionAll_graphs_Shortkey()), Qt::QueuedConnection);
}

MainWindow::~MainWindow()
{
  delete ui;
}

void  MainWindow::addPoint(double x, double y)
{
  gv_x.append(x);
  gv_y.append(y);
}

void  MainWindow::addPoint2(double x, double y)
{
  gv_x2.append(x);
  gv_y2.append(y);
}

void  MainWindow::addPoint3(double x, double y)
{
  gv_x3.append(x);
  gv_y3.append(y);
}

void  MainWindow::addPoint4(double x, double y)
{
  gv_x4.append(x);
  gv_y4.append(y);
}

void  MainWindow::autoAddPoint()
{
  if (chb_auto == true)
  {
    cleardata();
    bound_Auto();
  }
  else
  {
    cleardata();
    bound_range();
  }
}

void  MainWindow::cleardata()
{
  gv_x.clear();
  gv_y.clear();

  gv_x2.clear();
  gv_y2.clear();

  gv_x3.clear();
  gv_y3.clear();

  gv_x4.clear();
  gv_y4.clear();
}

void  MainWindow::clean_Selected_Graph()
{
  gv_x4.clear();
  gv_y4.clear();
}

void  MainWindow::plot()
{
  ui->plot->graph(0)->setData(gv_x, gv_y);
  ui->plot->replot();
  ui->plot->update();
}

void  MainWindow::plot2()
{
  ui->plot->graph(1)->setData(gv_x2, gv_y2);
  ui->plot->replot();
  ui->plot->update();
}

void  MainWindow::plot3()
{
  ui->plot->graph(2)->setData(gv_x3, gv_y3);
  ui->plot->replot();
  ui->plot->update();
}

void  MainWindow::plot4()
{
  switch (color_scautter)
  {
  case 10:
  {
    QCPScatterStyle::ScatterShape  Scatter_Items_Red = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Red->currentIndex());
    ui->plot->graph(3)->setData(gv_x4, gv_y4);
    ui->plot->graph(3)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Red, 20)));
    ui->plot->graph(3)->setPen(QPen(QColor(255, 0, 0, 255)));
    ui->plot->replot();
    ui->plot->update();

    break;
  }
  case 11:
  {
    QCPScatterStyle::ScatterShape  Scatter_Items_Green = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Green->currentIndex());
    ui->plot->graph(3)->setData(gv_x4, gv_y4);
    ui->plot->graph(3)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Green, 20)));
    ui->plot->graph(3)->setPen(QPen(QColor(0, 255, 0, 255)));
    ui->plot->replot();
    ui->plot->update();

    break;
  }
  case 12:
  {
    QCPScatterStyle::ScatterShape  Scatter_Items_Blue = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Blue->currentIndex());
    ui->plot->graph(3)->setData(gv_x4, gv_y4);
    ui->plot->graph(3)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Blue, 20)));
    ui->plot->graph(3)->setPen(QPen(QColor(0, 0, 255, 255)));
    ui->plot->replot();
    ui->plot->update();
    break;
  }
  }
}

void  MainWindow::plot4_Selected()
{
  ui->plot->graph(3)->setData(gv_x4, gv_y4);
  ui->plot->replot();
  ui->plot->update();
}

void  MainWindow::on_btn_add_clicked()
{
  addPoint(ui->bx_x->value(), ui->bx_y->value());
  plot();
}

void  MainWindow::xyGraph(QMouseEvent *event)
{
  QPoint   point22 = event->pos();
  QPoint   mos;
  QString  message, message1, messageall;
  double   x, y;

  x = ui->plot->xAxis->pixelToCoord(point22.x());
  y = ui->plot->yAxis->pixelToCoord(point22.y());

  if (chb_ShowPoint == true)
  {
    message = "X : " + QString::number(x) + "  Y : " + QString::number(y);
    QToolTip::showText(event->globalPos(), message);
  }

  if (ui->chc_EnableMode->isChecked())
  {
    mos.setX(ui->plot->xAxis->pixelToCoord(point22.x()));

    mos.setY(ui->plot->yAxis->pixelToCoord(point22.y()));

    double  tx0 = 0.0, tx1 = 0.0, tx2 = 0.0;
    double  ty0 = 0.0, ty1 = 0.0, ty2 = 0.0;

    QCPGraphDataContainer::const_iterator  it0 = ui->plot->graph(0)->data()->constEnd();
    QCPGraphDataContainer::const_iterator  it1 = ui->plot->graph(1)->data()->constEnd();
    QCPGraphDataContainer::const_iterator  it2 = ui->plot->graph(2)->data()->constEnd();
    QVariant                               details0, details1, details2;

    if (ui->plot->graph(0)->selectTest(event->localPos(), false, &details0))
    {
      QCPDataSelection  dataPoints0 = details0.value<QCPDataSelection>();

      if (dataPoints0.dataPointCount() > 0)
      {
        it0 = ui->plot->graph(0)->data()->at(dataPoints0.dataRange().begin());

        tx0 = (double)it0->key;
        ty0 = (double)it0->value;
      }

      if (ui->plot->graph(1)->selectTest(event->pos(), false, &details1))
      {
        QCPDataSelection  dataPoints1 = details1.value<QCPDataSelection>();

        if (dataPoints1.dataPointCount() > 0)
        {
          it1 = ui->plot->graph(1)->data()->at(dataPoints1.dataRange().begin());

          tx1 = (double)it1->key;
          ty1 = (double)it1->value;
        }
      }

      if (ui->plot->graph(2)->selectTest(event->pos(), false, &details2))
      {
        QCPDataSelection  dataPoints2 = details2.value<QCPDataSelection>();

        if (dataPoints2.dataPointCount() > 0)
        {
          it2 = ui->plot->graph(2)->data()->at(dataPoints2.dataRange().begin());

          tx2 = (double)it2->key;
          ty2 = (double)it2->value;
        }
      }

      double  dis0, dis1, dis2;

      dis0 = sqrt((x - tx0) * (x - tx0) + (y - ty0) * (y - ty0));
      dis1 = sqrt((x - tx1) * (x - tx1) + (y - ty1) * (y - ty1));
      dis2 = sqrt((x - tx2) * (x - tx2) + (y - ty2) * (y - ty2));

      // dis0=sqrt(pow((x-tx0),2)+pow((y-ty0),2));
      // dis1=sqrt(pow((x-tx1),2)+pow((y-ty1),2));
      // dis2=sqrt(pow((x-tx2),2)+pow((y-ty2),2));

      if ((dis0 < dis1) && (dis0 <= dis2))
      {
        message        = "X : " + QString::number(x) + "  Y : " + QString::number(y) + "\n" + "near with:\n";
        message1       = "X : " + QString::number(it0->key, 'f', 2) + "   Y : " + QString::number(it0->value, 'f', 2);
        color_scautter = 10;
        addPoint4((double)it0->key, (double)it0->value);
        plot4();
        gv_x4.clear();
        gv_y4.clear();
      }
      else if ((dis1 < dis0) && (dis1 <= dis2))
      {
        message        = "X : " + QString::number(x) + "  Y : " + QString::number(y) + "\n" + "near with:\n";
        message1       = "X : " + QString::number(it1->key, 'f', 2) + "   Y : " + QString::number(it1->value, 'f', 2);
        color_scautter = 11;
        addPoint4((double)it1->key, (double)it1->value);
        plot4();
        gv_x4.clear();
        gv_y4.clear();
      }
      else if ((dis2 < dis0) && (dis2 <= dis1))
      {
        message        = "X : " + QString::number(x) + "  Y : " + QString::number(y) + "\n" + "near with:\n";
        message1       = "X : " + QString::number(it2->key, 'f', 2) + "   Y : " + QString::number(it2->value, 'f', 2);
        color_scautter = 12;
        addPoint4((double)it2->key, (double)it2->value);
        plot4();
        gv_x4.clear();
        gv_y4.clear();
      }
    }
  }

  messageall = message + message1;
  QToolTip::showText(event->globalPos(), messageall);
}

void  MainWindow::on_btn_add2_clicked()
{
  addPoint2(ui->bx_x2->value(), ui->bx_y2->value());
  plot2();
}

void  MainWindow::on_btn_Clean_xy_clicked()
{
  gv_x.clear();
  gv_y.clear();

  plot();
  plot4_Selected();
}

void  MainWindow::on_btn_Clean_xy2_clicked()
{
  gv_x2.clear();
  gv_y2.clear();

  plot2();
  plot4_Selected();
}

void  MainWindow::on_bx_Num_Node_valueChanged(int arg1)
{
  num = arg1;

  if (num == 0)
  {
    ui->btn_Start_Stop->setEnabled(false);
  }
  else
  {
    ui->btn_Start_Stop->setEnabled(true);
  }
}

void  MainWindow::on_btn_Fix_Graph_clicked()
{
  if (chb_auto == false)
  {
    ui->plot->xAxis->setRange(0, max_X2_graphs);
    ui->plot->yAxis->setRange(0, max_Y2_graphs);

    ui->plot->xAxis2->setRange(0, max_X2_graphs);
    ui->plot->yAxis2->setRange(0, max_Y2_graphs);

    ui->plot->replot();
    ui->plot->update();
  }
  else
  {
    max_X2_graphs = 100;
    max_Y2_graphs = 100;
    ui->plot->xAxis->setRange(0, max_X2_graphs);
    ui->plot->yAxis->setRange(0, max_Y2_graphs);

    ui->plot->xAxis2->setRange(0, max_X2_graphs);
    ui->plot->yAxis2->setRange(0, max_Y2_graphs);
  }

  ui->plot->replot();
  ui->plot->update();
}

void  MainWindow::on_btn_add3_clicked()
{
  addPoint3(ui->bx_x3->value(), ui->bx_y3->value());
  plot3();
}

void  MainWindow::on_btn_Clean_xy3_clicked()
{
  gv_x3.clear();
  gv_y3.clear();
  plot3();
  plot4_Selected();
}

void  MainWindow::bound_Auto()
{
  count_Node_Grapgh = ui->bx_Num_Node->value();

  if (max_X2_graphs <= 100) { max_X2_graphs = 100; }

  if (max_Y2_graphs <= 100) { max_Y2_graphs = 100; }

  for (int i = 1; i <= count_Node_Grapgh; i++)
  {
    double  x = rd.global()->bounded(0.00, max_X2_graphs);
    x *= 1.031;

    double  y = rd.global()->bounded(0.00, max_Y2_graphs);
    y *= 1.031;

    double  x2 = rd.global()->bounded(0.00, max_X2_graphs);
    x2 *= 1.031;

    double  y2 = rd.global()->bounded(0.00, max_Y2_graphs);
    y2 *= 1.031;

    double  x3 = rd.global()->bounded(0.00, max_X2_graphs);
    x3 *= 1.031;

    double  y3 = rd.global()->bounded(0.00, max_Y2_graphs);
    y3 *= 1.031;

    addPoint(x, y);
    addPoint2(x2, y2);
    addPoint3(x3, y3);

    plot();
    plot2();
    plot3();
    plot4_Selected();
  }
}

void  MainWindow::bound_range()
{
  count_Node_Grapgh = ui->bx_Num_Node->value();
  max_X2_graphs     = 100;
  max_Y2_graphs     = 100;

  double  x0, x2, x3, y0, y2, y3;

  xRange1  = ui->bx_x_range1->value();
  xRange2  = ui->bx_x_range2->value();
  x2Range1 = ui->bx_x2_range1->value();
  x2Range2 = ui->bx_x2_range2->value();
  x3Range1 = ui->bx_x3_range1->value();
  x3Range2 = ui->bx_x3_range2->value();

  yRange1  = ui->bx_y_range1->value();
  yRange2  = ui->bx_y_range2->value();
  y2Range1 = ui->bx_y2_range1->value();
  y2Range2 = ui->bx_y2_range2->value();
  y3Range1 = ui->bx_y3_range1->value();
  y3Range2 = ui->bx_y3_range2->value();

  if (xRange1 >= max_X2_graphs) { max_X2_graphs = xRange1; }

  if (x2Range1 >= max_X2_graphs) { max_X2_graphs = x2Range1; }

  if (x3Range1 >= max_X2_graphs) { max_X2_graphs = x3Range1; }

  if (xRange2 >= max_X2_graphs) { max_X2_graphs = xRange2; }

  if (x2Range2 >= max_X2_graphs) { max_X2_graphs = x2Range2; }

  if (x3Range2 >= max_X2_graphs) { max_X2_graphs = x3Range2; }

  if (yRange1 >= max_Y2_graphs) { max_Y2_graphs = yRange1; }

  if (y2Range1 >= max_Y2_graphs) { max_Y2_graphs = y2Range1; }

  if (y3Range1 >= max_Y2_graphs) { max_Y2_graphs = y3Range1; }

  if (yRange2 >= max_Y2_graphs) { max_Y2_graphs = yRange2; }

  if (y2Range2 >= max_Y2_graphs) { max_Y2_graphs = y2Range2; }

  if (y3Range2 >= max_Y2_graphs) { max_Y2_graphs = y3Range2; }

  if (max_X2_graphs <= 100) { max_X2_graphs = 100; }

  if (max_Y2_graphs <= 100) { max_Y2_graphs = 100; }

  for (int i = 1; i <= count_Node_Grapgh; i++)
  {
    gv_x4.clear();
    gv_y4.clear();

    if ((xRange1 > 0) || (xRange2 > 0) || (yRange1 > 0) || (yRange2 > 0))
    {
      if (xRange1 >= xRange2)
      {
        int  xr = xRange1;
        xRange1 = xRange2;
        xRange2 = xr;
      }
      else if ((xRange1 >= 0) && (xRange2 != 0))
      {
        x0 = rd.global()->bounded(xRange1, xRange2);
      }

      if (yRange1 >= yRange2)
      {
        int  xr = yRange1;
        yRange1 = yRange2;
        yRange2 = xr;
      }
      else if ((yRange1 >= 0) && (yRange2 != 0))
      {
        y0 = rd.global()->bounded(yRange1, yRange2);
      }

      addPoint(x0, y0);
    }

    if ((x2Range1 > 0) || (x2Range2 > 0) || (y2Range1 > 0) || (y2Range2 > 0))
    {
      if (x2Range1 >= x2Range2)
      {
        int  xr = x2Range1;
        x2Range1 = x2Range2;
        x2Range2 = xr;
      }
      else if ((x2Range1 >= 0) && (x2Range2 != 0))
      {
        x2 = rd.global()->bounded(x2Range1, x2Range2);
      }

      if (y2Range1 >= y2Range2)
      {
        int  xr = y2Range1;
        y2Range1 = y2Range2;
        y2Range2 = xr;
      }
      else if ((y2Range1 >= 0) && (y2Range2 != 0))
      {
        y2 = rd.global()->bounded(y2Range1, y2Range2);
      }

      addPoint2(x2, y2);
    }

    if ((x3Range1 > 0) || (x3Range2 > 0) || (y3Range1 > 0) || (y3Range2 > 0))
    {
      if (x3Range1 >= x3Range2)
      {
        int  xr = x3Range1;
        x3Range1 = x3Range2;
        x3Range2 = xr;
      }
      else if ((x3Range1 >= 0) && (x3Range2 != 0))
      {
        x3 = rd.global()->bounded(x3Range1, x3Range2);
      }

      if (y3Range1 >= y3Range2)
      {
        int  xr = y3Range1;
        y3Range1 = y3Range2;
        y3Range2 = xr;
      }
      else if ((y3Range1 >= 0) && (y3Range2 != 0))
      {
        y3 = rd.global()->bounded(y3Range1, y3Range2);
      }

      addPoint3(x3, y3);
    }

    plot();
    plot2();
    plot3();
    plot4_Selected();
  }
}

void  MainWindow::on_chb_Bound_Bandom_toggled(bool checked)
{
  if (checked)
  {
    ui->grpbx_Bunded->setEnabled(true);
    ui->actionFix_bound_or_randome_range->setChecked(true);
    chb_auto = false;
  }
  else
  {
    ui->grpbx_Bunded->setEnabled(false);
    ui->actionFix_bound_or_randome_range->setChecked(false);
    chb_auto = true;
  }
}

void  MainWindow::removePoint(double x, double y)
{
  gv_x.removeOne(x);
  gv_y.removeOne(y);
}

void  MainWindow::removePoint2(double x, double y)
{
  gv_x2.removeOne(x);
  gv_y2.removeOne(y);
}

void  MainWindow::removePoint3(double x, double y)
{
  gv_x3.removeOne(x);
  gv_y3.removeOne(y);
}

void  MainWindow::on_btn_Del_R_clicked()
{
  removePoint(ui->bx_x->value(), ui->bx_y->value());
  plot();
}

void  MainWindow::on_btn_Del_G_clicked()
{
  removePoint2(ui->bx_x2->value(), ui->bx_y2->value());
  plot2();
}

void  MainWindow::on_btn_Del_B_clicked()
{
  removePoint3(ui->bx_x3->value(), ui->bx_y3->value());
  plot3();
}

void  MainWindow::on_cbox_ScatterStyle_Red_currentIndexChanged(int index)
{
  Q_UNUSED(index);
  QCPScatterStyle::ScatterShape  Scatter_Items_Red    = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Red->currentIndex());
  QCPGraph::LineStyle            LineStyle_Iteams_Red = (QCPGraph::LineStyle)(ui->cbox_StyleLine_Red->currentIndex());

  ui->plot->graph(0)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Red, ui->cbox_Size_Red->value())));
  ui->plot->graph(0)->setLineStyle(LineStyle_Iteams_Red);

  ui->plot->update();
  ui->plot->replot();
}

void  MainWindow::on_cbox_ScatterStyle_Green_currentIndexChanged(int index)
{
  Q_UNUSED(index);
  QCPScatterStyle::ScatterShape  Scatter_Items_Green    = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Green->currentIndex());
  QCPGraph::LineStyle            LineStyle_Iteams_Green = (QCPGraph::LineStyle)(ui->cbox_StyleLine_Green->currentIndex());

  ui->plot->graph(1)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Green, ui->cbox_Size_Green->value())));
  ui->plot->graph(1)->setLineStyle(LineStyle_Iteams_Green);

  ui->plot->update();
  ui->plot->replot();
}

void  MainWindow::on_cbox_ScatterStyle_Blue_currentIndexChanged(int index)
{
  Q_UNUSED(index);
  QCPScatterStyle::ScatterShape  Scatter_Items_Blue    = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Blue->currentIndex());
  QCPGraph::LineStyle            LineStyle_Iteams_Blue = (QCPGraph::LineStyle)(ui->cbox_StyleLine_Blue->currentIndex());

  ui->plot->graph(2)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Blue, ui->cbox_Size_Blue->value())));
  ui->plot->graph(2)->setLineStyle(LineStyle_Iteams_Blue);

  ui->plot->update();
  ui->plot->replot();
}

void  MainWindow::on_cbox_StyleLine_Red_currentIndexChanged(int index)
{
  Q_UNUSED(index);
  QCPGraph::LineStyle  LineStyle_Iteams_Red = (QCPGraph::LineStyle)(ui->cbox_StyleLine_Red->currentIndex());

  ui->plot->graph(0)->setLineStyle(LineStyle_Iteams_Red);

  ui->plot->update();
  ui->plot->replot();
}

void  MainWindow::on_cbox_StyleLine_Green_currentIndexChanged(int index)
{
  Q_UNUSED(index);
  QCPGraph::LineStyle  LineStyle_Iteams_Green = (QCPGraph::LineStyle)(ui->cbox_StyleLine_Green->currentIndex());

  ui->plot->graph(1)->setLineStyle(LineStyle_Iteams_Green);

  ui->plot->update();
  ui->plot->replot();
}

void  MainWindow::on_cbox_StyleLine_Blue_currentIndexChanged(int index)
{
  Q_UNUSED(index);
  QCPGraph::LineStyle  LineStyle_Iteams_Blue = (QCPGraph::LineStyle)(ui->cbox_StyleLine_Blue->currentIndex());

  ui->plot->graph(2)->setLineStyle(LineStyle_Iteams_Blue);

  ui->plot->update();
  ui->plot->replot();
}

void  MainWindow::on_cbox_Size_Red_valueChanged(int arg1)
{
  QCPScatterStyle::ScatterShape  Scatter_Items_Red = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Red->currentIndex());

  ui->plot->graph(0)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Red, arg1)));

  ui->plot->update();
  ui->plot->replot();
}

void  MainWindow::on_cbox_Size_Green_valueChanged(int arg1)
{
  QCPScatterStyle::ScatterShape  Scatter_Items_Green = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Green->currentIndex());

  ui->plot->graph(1)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Green, arg1)));

  ui->plot->update();
  ui->plot->replot();
}

void  MainWindow::on_cbox_Size_Blue_valueChanged(int arg1)
{
  QCPScatterStyle::ScatterShape  Scatter_Items_Blue = (QCPScatterStyle::ScatterShape)(ui->cbox_ScatterStyle_Blue->currentIndex());

  ui->plot->graph(2)->setScatterStyle(QCPScatterStyle(QCPScatterStyle(Scatter_Items_Blue, arg1)));

  ui->plot->update();
  ui->plot->replot();
}

void  MainWindow::on_chc_EnableMode_toggled(bool checked)
{
  plot4_Selected();

  if (checked)
  {
    ui->actionEnable_selection_mode->setChecked(true);
    ui->plot->graph(3)->setVisible(true);
  }
  else
  {
    ui->plot->graph(3)->setVisible(false);
    ui->actionEnable_selection_mode->setChecked(false);
  }
}

void  MainWindow::on_actionRed_triggered(bool checked)
{
  if (checked)
  {
    ui->plot->graph(0)->setVisible(true);
    irec_Red->setVisible(true);
    ui->plot->replot();
    plot4_Selected();
  }
  else
  {
    ui->plot->graph(0)->setVisible(false);
    irec_Red->setVisible(false);
    ui->plot->replot();
    plot4_Selected();
  }

  check_Allgrapg();
}

void  MainWindow::on_actionGreen_triggered(bool checked)
{
  if (checked)
  {
    ui->plot->graph(1)->setVisible(true);
    irec_Green->setVisible(true);
    ui->plot->replot();
    plot4_Selected();
  }
  else
  {
    ui->plot->graph(1)->setVisible(false);
    irec_Green->setVisible(false);
    ui->plot->replot();
    plot4_Selected();
  }

  check_Allgrapg();
}

void  MainWindow::on_actionBlue_triggered(bool checked)
{
  if (checked)
  {
    ui->plot->graph(2)->setVisible(true);
    irec_Blue->setVisible(true);
    ui->plot->replot();
    plot4_Selected();
  }
  else
  {
    ui->plot->graph(2)->setVisible(false);
    irec_Blue->setVisible(false);
    ui->plot->replot();
    plot4_Selected();
  }

  check_Allgrapg();
}

void  MainWindow::on_actionAll_graphs_triggered(bool checked)
{
  if (checked)
  {
    ui->plot->graph(0)->setVisible(true);
    ui->plot->graph(1)->setVisible(true);
    ui->plot->graph(2)->setVisible(true);
    ui->plot->graph(3)->setVisible(true);

    irec_Red->setVisible(true);
    irec_Green->setVisible(true);
    irec_Blue->setVisible(true);

    ui->actionRed->setChecked(true);
    ui->actionGreen->setChecked(true);
    ui->actionBlue->setChecked(true);

    ui->plot->replot();
  }
  else
  {
    ui->plot->graph(0)->setVisible(false);
    ui->plot->graph(1)->setVisible(false);
    ui->plot->graph(2)->setVisible(false);
    ui->plot->graph(3)->setVisible(false);

    ui->actionRed->setChecked(false);
    ui->actionGreen->setChecked(false);
    ui->actionBlue->setChecked(false);

    irec_Red->setVisible(false);
    irec_Green->setVisible(false);
    irec_Blue->setVisible(false);

    ui->plot->replot();
  }
}

void  MainWindow::actionRed_Shortkey()
{
  if (ui->actionRed->isChecked())
  {
    ui->plot->graph(0)->setVisible(false);
    irec_Red->setVisible(false);
    ui->plot->replot();
    ui->actionRed->setChecked(false);
    plot4_Selected();
  }
  else
  {
    ui->plot->graph(0)->setVisible(true);
    irec_Red->setVisible(true);
    ui->plot->replot();
    ui->actionRed->setChecked(true);
    plot4_Selected();
  }

  check_Allgrapg();
}

void  MainWindow::actionGreen_Shortkey()
{
  if (ui->actionGreen->isChecked())
  {
    ui->plot->graph(1)->setVisible(false);
    irec_Green->setVisible(false);
    ui->plot->replot();
    ui->actionGreen->setChecked(false);
    plot4_Selected();
  }
  else
  {
    ui->plot->graph(1)->setVisible(true);
    irec_Green->setVisible(true);
    ui->plot->replot();
    ui->actionGreen->setChecked(true);
    plot4_Selected();
  }

  check_Allgrapg();
}

void  MainWindow::actionBlue_Shortkey()
{
  if (ui->actionBlue->isChecked())
  {
    ui->plot->graph(2)->setVisible(false);
    irec_Blue->setVisible(false);
    ui->plot->replot();
    ui->actionBlue->setChecked(false);
    plot4_Selected();
  }
  else
  {
    ui->plot->graph(2)->setVisible(true);
    irec_Blue->setVisible(true);
    ui->plot->replot();
    ui->actionBlue->setChecked(true);
    plot4_Selected();
  }

  check_Allgrapg();
}

void  MainWindow::actionAll_graphs_Shortkey()
{
  if (!(ui->actionAll_graphs->isChecked()))
  {
    ui->plot->graph(0)->setVisible(true);
    ui->plot->graph(1)->setVisible(true);
    ui->plot->graph(2)->setVisible(true);
    ui->plot->graph(3)->setVisible(true);

    irec_Red->setVisible(true);
    irec_Green->setVisible(true);
    irec_Blue->setVisible(true);

    ui->actionRed->setChecked(true);
    ui->actionGreen->setChecked(true);
    ui->actionBlue->setChecked(true);

    ui->actionAll_graphs->setChecked(true);

    ui->plot->replot();
  }
  else
  {
    ui->plot->graph(0)->setVisible(false);
    ui->plot->graph(1)->setVisible(false);
    ui->plot->graph(2)->setVisible(false);
    ui->plot->graph(3)->setVisible(false);

    ui->actionRed->setChecked(false);
    ui->actionGreen->setChecked(false);
    ui->actionBlue->setChecked(false);

    irec_Red->setVisible(false);
    irec_Green->setVisible(false);
    irec_Blue->setVisible(false);

    ui->actionAll_graphs->setChecked(false);

    ui->plot->replot();
  }
}

void  MainWindow::on_actionEnable_selection_mode_triggered(bool checked)
{
  plot4_Selected();

  if (checked)
  {
    ui->chc_EnableMode->setChecked(true);
    ui->plot->graph(3)->setVisible(true);
  }
  else
  {
    ui->plot->graph(3)->setVisible(false);
    ui->chc_EnableMode->setChecked(false);
  }
}

void  MainWindow::on_actionFix_bound_or_randome_range_triggered(bool checked)
{
  if (checked)
  {
    ui->grpbx_Bunded->setEnabled(true);
    ui->chb_Bound_Bandom->setChecked(true);
    chb_auto = false;
  }
  else
  {
    ui->grpbx_Bunded->setEnabled(false);
    ui->chb_Bound_Bandom->setChecked(false);
    chb_auto = true;
  }
}

void  MainWindow::on_actionFix_graphs_triggered()
{
  on_btn_Fix_Graph_clicked();
}

void  MainWindow::graph_Menu(QMouseEvent *event)
{
  QMenu *menuGraph = new QMenu(this);

  menuGraph->setAttribute(Qt::WA_DeleteOnClose);

  QPoint  p = event->pos();

  if (event->button() == Qt::RightButton)
  {
    if (ui->plot->legend->selectTest(p, false) >= 0)
    {
      menuGraph->addAction("Move to top left", this, SLOT(moveLegend()))->setData((int)(Qt::AlignTop | Qt::AlignLeft));
      menuGraph->addAction("Move to top center", this, SLOT(moveLegend()))->setData((int)(Qt::AlignTop | Qt::AlignHCenter));
      menuGraph->addAction("Move to top right", this, SLOT(moveLegend()))->setData((int)(Qt::AlignTop | Qt::AlignRight));

      menuGraph->addAction("Move to bottom left", this, SLOT(moveLegend()))->setData((int)(Qt::AlignBottom | Qt::AlignLeft));
      menuGraph->addAction("Move to bottom center", this, SLOT(moveLegend()))->setData((int)(Qt::AlignBottom | Qt::AlignHCenter));
      menuGraph->addAction("Move to bottom right", this, SLOT(moveLegend()))->setData((int)(Qt::AlignBottom | Qt::AlignRight));

      menuGraph->popup(ui->plot->mapToGlobal(p));
    }
    else
    {
      ui->menuMenu->popup(this->mapToGlobal(p));
    }

    ui->plot->replot();
  }
}

void  MainWindow::check_Allgrapg()
{
  if (ui->actionRed->isChecked() && ui->actionGreen->isChecked() && ui->actionBlue->isChecked())
  {
    ui->actionAll_graphs->setChecked(true);
  }
  else
  {
    ui->actionAll_graphs->setChecked(false);
  }
}

void  MainWindow::on_actionFix_grapgs_triggered()
{
  on_btn_Fix_Graph_clicked();
}

void  MainWindow::on_actionRed_Cleen_triggered()
{
  gv_x.clear();
  gv_y.clear();

  plot();
  plot4_Selected();

  ui->plot->graph(0)->data().clear();

  irec_Red->setVisible(false);
  ui->chb_Zone_Red->setChecked(false);
  ui->plot->replot();
}

void  MainWindow::actionGreen_Clean_triggered()
{
  gv_x2.clear();
  gv_y2.clear();

  plot2();
  plot4_Selected();

  ui->plot->graph(1)->data().clear();
  irec_Green->setVisible(false);
  ui->chb_Zone_Green->setChecked(false);
  ui->plot->replot();
}

void  MainWindow::on_actionBlue_Cleen_triggered()
{
  gv_x3.clear();
  gv_y3.clear();
  plot3();
  plot4_Selected();

  ui->plot->graph(2)->data().clear();

  irec_Blue->setVisible(false);
  ui->chb_Zone_Blue->setChecked(false);
  ui->plot->replot();
}

void  MainWindow::on_actionAll_Graphs_Clean_triggered()
{
  cleardata();

  plot();
  plot2();
  plot3();

  plot4_Selected();
  irec_Red->setVisible(false);
  ui->chb_Zone_Red->setChecked(false);

  irec_Green->setVisible(false);
  ui->chb_Zone_Green->setChecked(false);

  irec_Blue->setVisible(false);
  ui->chb_Zone_Blue->setChecked(false);

  ui->plot->replot();
}

void  MainWindow::moveLegend()
{
  if (QAction *contextAction = qobject_cast<QAction *>(sender()))
  {
    bool  ok      = true;
    int   dataInt = contextAction->data().toInt();

    if (ok)
    {
      ui->plot->axisRect()->insetLayout()->setInsetAlignment(0, (Qt::Alignment)dataInt);
      ui->plot->replot();
    }
  }
}

void  MainWindow::on_chb_ShowPointCoordinates_toggled(bool checked)
{
  if (checked)
  {
    ui->actionEnable_show_point_coordinates->setChecked(true);
    chb_ShowPoint = true;
  }
  else
  {
    ui->actionEnable_show_point_coordinates->setChecked(false);
    chb_ShowPoint = false;
  }
}

void  MainWindow::on_actionEnable_show_point_coordinates_triggered(bool checked)
{
  if (checked)
  {
    ui->chb_ShowPointCoordinates->setChecked(true);
    chb_ShowPoint = true;
  }
  else
  {
    ui->chb_ShowPointCoordinates->setChecked(false);
    chb_ShowPoint = false;
  }
}

void  MainWindow::on_actionStart_stop_triggered()
{
  if (start_Stop)
  {
    on_btn_Start_Stop_toggled();
  }
  else
  {
    on_btn_Start_Stop_toggled();
  }
}

void  MainWindow::on_btn_Start_Stop_toggled()
{
  UpdateTime  = ui->bx_UpdateTime->value();
  UpdateTime *= 1000;

  if (start_Stop)
  {
    time->start(UpdateTime);

    ui->btn_Start_Stop->setText("Stop");
    ui->actionStart_stop->setText("Stop");

    ui->actionStart_stop->setIcon(QIcon(":/Icon/pause.jpg"));
    // ui->actionStart_stop->setShortcut(QKeySequence(/*Qt::CTRL + Qt::SHIFT + Qt::Key_P|*/ Qt::Key_Stop));
    start_Stop = false;
  }
  else
  {
    time->stop();

    ui->btn_Start_Stop->setText("Start");
    ui->actionStart_stop->setText("Start");

    ui->actionStart_stop->setIcon(QIcon(":/Icon/play.jpg"));
    // ui->actionStart_stop->setShortcut(QKeySequence(/*Qt::CTRL + Qt::SHIFT + Qt::Key_P|*/ Qt::Key_Play));
    start_Stop = true;
  }
}

void  MainWindow::on_rb_RightClick_Menu_toggled(bool checked)
{
  if (checked)
  {
    connect(ui->plot, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(graph_Menu(QMouseEvent*)));
  }
  else
  {
    disconnect(ui->plot, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(graph_Menu(QMouseEvent*)));
  }
}

void  MainWindow::on_rb_RightClick_Editor_toggled(bool checked)
{
  if (checked)
  {
    connect(ui->plot, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(Zoom_Drag(QMouseEvent*)));
  }
  else
  {
    disconnect(ui->plot, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(Zoom_Drag(QMouseEvent*)));
  }
}

void  MainWindow::Zoom_Drag(QMouseEvent *event)
{
  if (event->button() == Qt::LeftButton)
  {
    ui->plot->setSelectionRectMode(QCP::srmZoom);
  }
  else if (event->button() == Qt::RightButton)
  {
    ui->plot->setSelectionRectMode(QCP::srmNone);
    ui->plot->setInteractions(QCP::iRangeDrag | QCP::iMultiSelect | QCP::iSelectItems);
  }
}

void  MainWindow::rezoom()
{
  ui->plot->rescaleAxes();
  ui->plot->replot();
}

void  MainWindow::on_chb_Zone_Red_toggled(bool checked)
{
  if (checked)
  {
    if (ui->plot->hasItem(irec_Red))
    {
      ui->plot->removeItem(irec_Red);
    }

    irec_Red = new QCPItemRect(ui->plot);

    irec_Red->bottomRight->setCoords(ui->bx_x_range1->value(), ui->bx_y_range1->value());
    irec_Red->topLeft->setCoords(ui->bx_x_range2->value(), ui->bx_y_range2->value());

    irec_Red->topLeft->setAxisRect(xrec_Red);
    irec_Red->bottomRight->setAxisRect(xrec_Red);
    irec_Red->setBrush(QBrush(QColor(255, 0, 0, 75)));
    irec_Red->setPen(QPen(Qt::red));
    ui->plot->replot();
  }
  else if (ui->plot->hasItem(irec_Red))
  {
    ui->plot->removeItem(irec_Red);
    ui->plot->replot();
  }

  Zone_All_plot();
}

void  MainWindow::on_chb_Zone_Green_toggled(bool checked)
{
  if (checked)
  {
    if (ui->plot->hasItem(irec_Green))
    {
      ui->plot->removeItem(irec_Green);
    }

    irec_Green = new QCPItemRect(ui->plot);

    irec_Green->topLeft->setCoords(ui->bx_x2_range2->value(), ui->bx_y2_range2->value());
    irec_Green->bottomRight->setCoords(ui->bx_x2_range1->value(), ui->bx_y2_range1->value());

    irec_Green->topLeft->setAxisRect(xrec_Green);
    irec_Green->bottomRight->setAxisRect(xrec_Green);
    irec_Green->setBrush(QBrush(QColor(0, 255, 0, 75)));
    irec_Green->setPen(QPen(Qt::green));
    ui->plot->replot();
  }
  else if (ui->plot->hasItem(irec_Green))
  {
    ui->plot->removeItem(irec_Green);
    ui->plot->replot();
  }

  Zone_All_plot();
}

void  MainWindow::on_chb_Zone_Blue_toggled(bool checked)
{
  if (checked)
  {
    if (ui->plot->hasItem(irec_Blue))
    {
      ui->plot->removeItem(irec_Blue);
    }

    irec_Blue = new QCPItemRect(ui->plot);

    irec_Blue->topLeft->setCoords(ui->bx_x3_range2->value(), ui->bx_y3_range2->value());
    irec_Blue->bottomRight->setCoords(ui->bx_x3_range1->value(), ui->bx_y3_range1->value());

    irec_Blue->bottomRight->setAxisRect(xrec_Blue);
    irec_Blue->topLeft->setAxisRect(xrec_Blue);
    irec_Blue->setPen(QPen(Qt::blue));
    irec_Blue->setBrush(QBrush(QColor(0, 0, 255, 75)));
    ui->plot->replot();
  }
  else if (ui->plot->hasItem(irec_Blue))
  {
    ui->plot->removeItem(irec_Blue);
    ui->plot->replot();
  }

  Zone_All_plot();
}

void  MainWindow::on_chb_Zone_All_toggled(bool checked)
{
  if (checked)
  {
    ui->chb_Zone_Red->setChecked(checked);
    // on_chb_Zone_Red_toggled(checked);

    ui->chb_Zone_Green->setChecked(checked);
    // on_chb_Zone_Green_toggled(checked);

    ui->chb_Zone_Blue->setChecked(checked);
    // on_chb_Zone_Blue_toggled(checked);
  }
  else
  {
    ui->chb_Zone_Red->setChecked(checked);
    // on_chb_Zone_Red_toggled(checked);

    ui->chb_Zone_Green->setChecked(checked);
    // on_chb_Zone_Green_toggled(checked);

    ui->chb_Zone_Blue->setChecked(checked);
    // on_chb_Zone_Blue_toggled(checked);
  }
}

void  MainWindow::Zone_All_plot()
{
  if ((ui->chb_Zone_Red->isChecked() == true) && (ui->chb_Zone_Green->isChecked() == true) && (ui->chb_Zone_Blue->isChecked() == true))
  {
    ui->chb_Zone_All->setChecked(true);
    on_chb_Zone_All_toggled(true);
  }

  if ((ui->chb_Zone_Red->isChecked() == false) && (ui->chb_Zone_Green->isChecked() == false) && (ui->chb_Zone_Blue->isChecked() == false))
  {
    ui->chb_Zone_All->setChecked(false);
    on_chb_Zone_All_toggled(false);
  }
}

void  MainWindow::drag_mouseRelease(QMouseEvent *event)
{
  _enablePress    = false;
  p_Mouse_Release = event->pos();

  if (event->button() == Qt::LeftButton)
  {
    x_mouseRelease = ui->plot->xAxis->pixelToCoord(p_Mouse_Release.x());
    y_mouseRelease = ui->plot->yAxis->pixelToCoord(p_Mouse_Release.y());
  }

  drag_plot();
}

void  MainWindow::drag_mousePress(QMouseEvent *event)
{
  _enablePress  = true;
  p_Mouse_Press = event->pos();

  if (event->button() == Qt::LeftButton)
  {
    x_mousePress = ui->plot->xAxis->pixelToCoord(p_Mouse_Press.x());
    y_mousePress = ui->plot->yAxis->pixelToCoord(p_Mouse_Press.y());
  }
}

void  MainWindow::drag_mouseMove(QMouseEvent *event)
{
  p_Mouse_Move = event->pos();

  xRectItem->setPen(QPen(Qt::transparent));
  xRectItem->setBrush(QBrush(QColor(0, 255, 0, 70)));

  xRectItem->topLeft->setType(QCPItemPosition::ptPlotCoords);
  xRectItem->topLeft->setAxisRect(xRect);

  xRectItem->bottomRight->setType(QCPItemPosition::ptPlotCoords);
  xRectItem->bottomRight->setAxisRect(xRect);

  x_mouseMove = ui->plot->xAxis->pixelToCoord(p_Mouse_Move.x());
  y_mouseMove = ui->plot->yAxis->pixelToCoord(p_Mouse_Move.y());

  if (_enablePress)
  {
    ui->x11->setValue(x_mouseMove);
    ui->y11->setValue(y_mouseMove);

    if (abs(x_mousePress - x_mouseMove) > abs(y_mousePress - y_mouseMove))
    {
      xRectItem->topLeft->setCoords(ui->plot->xAxis->range().upper, y_mousePress);
      xRectItem->bottomRight->setCoords(ui->plot->xAxis->range().lower, y_mouseMove);

      xRectItem->setClipAxisRect(xRect);
      xRectItem->setClipToAxisRect(false);

      ui->plot->update();
      ui->plot->replot();
    }
    else
    {
      xRectItem->topLeft->setCoords(x_mousePress, ui->plot->yAxis->range().upper);
      xRectItem->bottomRight->setCoords(x_mouseMove, ui->plot->yAxis->range().lower);

      xRectItem->setClipAxisRect(xRect);
      xRectItem->setClipToAxisRect(false);

      ui->plot->update();
      ui->plot->replot();
    }
  }
}

void  MainWindow::drag_plot()
{
  xRectItem->setPen(QPen(Qt::transparent));
  xRectItem->setBrush(QBrush(QColor(0, 255, 0, 150)));

  xRectItem->topLeft->setType(QCPItemPosition::ptPlotCoords);
  xRectItem->topLeft->setAxisRect(xRect);

  xRectItem->bottomRight->setType(QCPItemPosition::ptPlotCoords);
  xRectItem->bottomRight->setAxisRect(xRect);

  if (abs(x_mousePress - x_mouseRelease) > abs(y_mousePress - y_mouseRelease))
  {
    xRectItem->topLeft->setCoords(ui->plot->xAxis->range().upper, y_mousePress);
    xRectItem->bottomRight->setCoords(ui->plot->xAxis->range().lower, y_mouseRelease);
  }
  else
  {
    xRectItem->topLeft->setCoords(x_mousePress, ui->plot->yAxis->range().upper);
    xRectItem->bottomRight->setCoords(x_mouseRelease, ui->plot->yAxis->range().lower);
  }

  xRectItem->setClipAxisRect(xRect);
  xRectItem->setClipToAxisRect(false);
  ui->plot->update();
  ui->plot->replot();
}

void  MainWindow::on_chb_ShowBund_toggled(bool checked)
{
  if (checked)
  {
    connect(ui->plot, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(drag_mouseRelease(QMouseEvent*)));
    connect(ui->plot, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(drag_mousePress(QMouseEvent*)));
    connect(ui->plot, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(drag_mouseMove(QMouseEvent*)));

    disconnect(ui->plot, SIGNAL(mouseDoubleClick(QMouseEvent*)), this, SLOT(rezoom()));
    disconnect(ui->plot, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(Zoom_Drag(QMouseEvent*)));
  }
  else
  {
    disconnect(ui->plot, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(drag_mouseRelease(QMouseEvent*)));
    disconnect(ui->plot, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(drag_mousePress(QMouseEvent*)));
    disconnect(ui->plot, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(drag_mouseMove(QMouseEvent*)));

    connect(ui->plot, SIGNAL(mouseDoubleClick(QMouseEvent*)), this, SLOT(rezoom()));
    connect(ui->plot, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(Zoom_Drag(QMouseEvent*)));

    ui->plot->removeItem(xRectItem);
    ui->plot->replot();
    xRectItem = new QCPItemRect(ui->plot);
  }
}

void  MainWindow::draw(QCPPainter *painter)const
{
  if (!painter || !painter->isActive())
  {
    QMessageBox  msg;
    msg.setText(Q_FUNC_INFO);
    msg.exec();
  }
}

void  MainWindow::on_bx_x_range1_valueChanged(int arg1)
{
  xRange1 = arg1;
  on_chb_Zone_Red_toggled(ui->chb_Zone_Red->checkState());
}

void  MainWindow::on_bx_x_range2_valueChanged(int arg1)
{
  xRange2 = arg1;
  on_chb_Zone_Red_toggled(ui->chb_Zone_Red->checkState());
}

void  MainWindow::on_bx_y_range1_valueChanged(int arg1)
{
  yRange1 = arg1;
  on_chb_Zone_Red_toggled(ui->chb_Zone_Red->checkState());
}

void  MainWindow::on_bx_y_range2_valueChanged(int arg1)
{
  yRange2 = arg1;
  on_chb_Zone_Red_toggled(ui->chb_Zone_Red->checkState());
}

void  MainWindow::on_bx_x2_range1_valueChanged(int arg1)
{
  x2Range1 = arg1;
  on_chb_Zone_Green_toggled(ui->chb_Zone_Green->checkState());
}

void  MainWindow::on_bx_x2_range2_valueChanged(int arg1)
{
  x2Range2 = arg1;
  on_chb_Zone_Green_toggled(ui->chb_Zone_Green->checkState());
}

void  MainWindow::on_bx_y2_range1_valueChanged(int arg1)
{
  y2Range1 = arg1;
  on_chb_Zone_Green_toggled(ui->chb_Zone_Green->checkState());
}

void  MainWindow::on_bx_y2_range2_valueChanged(int arg1)
{
  y2Range2 = arg1;
  on_chb_Zone_Green_toggled(ui->chb_Zone_Green->checkState());
}

void  MainWindow::on_bx_x3_range1_valueChanged(int arg1)
{
  x3Range1 = arg1;
  on_chb_Zone_Blue_toggled(ui->chb_Zone_Blue->checkState());
}

void  MainWindow::on_bx_x3_range2_valueChanged(int arg1)
{
  x3Range2 = arg1;
  on_chb_Zone_Blue_toggled(ui->chb_Zone_Blue->checkState());
}

void  MainWindow::on_bx_y3_range1_valueChanged(int arg1)
{
  y3Range1 = arg1;
  on_chb_Zone_Blue_toggled(ui->chb_Zone_Blue->checkState());
}

void  MainWindow::on_bx_y3_range2_valueChanged(int arg1)
{
  y3Range2 = arg1;
  on_chb_Zone_Blue_toggled(ui->chb_Zone_Blue->checkState());
}

void  MainWindow::on_chb_Distance_toggled(bool checked)
{
  if (checked)
  {
    lab_Distance  = new QCPItemText(ui->plot);
    line_Distance = new QCPItemLine(ui->plot);

    line_Distance->setHead(QCPLineEnding::esSpikeArrow);
    line_Distance->setTail(QCPLineEnding::esBar);

    lab_Distance->setPen(QPen(QColor(204, 136, 0, 255), 2));
    lab_Distance->setBrush(QBrush(QColor(0, 255, 255, 255)));

    lab_Distance->setFont(QFont("Times", 12, QFont::Bold));

    ui->plot->setSelectionRectMode(QCP::srmNone);
    ui->plot->setInteraction(QCP::iRangeDrag, false);
    ui->plot->setInteraction(QCP::iRangeZoom, false);

    connect(ui->plot, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(distance_mousePress(QMouseEvent*)));
    connect(ui->plot, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(distance_mouseMove(QMouseEvent*)));
    connect(ui->plot, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(distance_mouseRelease(QMouseEvent*)));
  }
  else
  {
    ui->plot->setSelectionRectMode(QCP::srmSelect);
    ui->plot->setInteraction(QCP::iRangeDrag, true);
    ui->plot->setInteraction(QCP::iRangeZoom, true);

    disconnect(ui->plot, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(distance_mousePress(QMouseEvent*)));
    disconnect(ui->plot, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(distance_mouseMove(QMouseEvent*)));
    disconnect(ui->plot, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(distance_mouseRelease(QMouseEvent*)));

    ui->plot->removeItem(line_Distance);
    ui->plot->removeItem(lab_Distance);

    ui->plot->replot();
  }
}

void  MainWindow::distance_mousePress(QMouseEvent *event)
{
  _enableDistance = true;
  p_Mouse_Press   = event->pos();

  if (event->button() == Qt::LeftButton)
  {
    x_mousePress = ui->plot->xAxis->pixelToCoord(p_Mouse_Press.x());
    y_mousePress = ui->plot->yAxis->pixelToCoord(p_Mouse_Press.y());
  }

  ui->plot->replot();
}

void  MainWindow::distance_mouseMove(QMouseEvent *event)
{
  double  count_Distance;

  p_Mouse_Move = event->pos();

  if (_enableDistance)
  {
    x_mouseMove = ui->plot->xAxis->pixelToCoord(p_Mouse_Move.x());
    y_mouseMove = ui->plot->yAxis->pixelToCoord(p_Mouse_Move.y());

    line_Distance->start->setCoords(x_mousePress, y_mousePress);
    line_Distance->end->setCoords(x_mouseMove, y_mouseMove);

    count_Distance = sqrt(pow(x_mousePress - x_mouseMove, 2) + pow(y_mousePress - y_mouseMove, 2));

    lab_Distance->position->setCoords(x_mouseMove + 2, y_mouseMove + 2);
    lab_Distance->setText(QString::number(count_Distance));
  }

  ui->plot->replot();
}

void  MainWindow::distance_mouseRelease(QMouseEvent *event)
{
  _enableDistance = false;
  p_Mouse_Release = event->pos();

  if (event->button() == Qt::LeftButton)
  {
    x_mouseRelease = ui->plot->xAxis->pixelToCoord(p_Mouse_Release.x());
    y_mouseRelease = ui->plot->yAxis->pixelToCoord(p_Mouse_Release.y());
  }
}
