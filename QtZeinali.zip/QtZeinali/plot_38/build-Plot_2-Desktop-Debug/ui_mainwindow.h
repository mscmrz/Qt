/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionRed;
    QAction *actionGreen;
    QAction *actionBlue;
    QAction *actionAll_graphs;
    QAction *actionFix_bound_or_randome_range;
    QAction *actionEnable_selection_mode;
    QAction *actionALL_graphs;
    QAction *actionFix_grapgs;
    QAction *actionRed_Cleen;
    QAction *actionGreen_Cean;
    QAction *actionBlue_Cleen;
    QAction *actionAll_Graphs_Clean;
    QAction *actionStart_stop;
    QAction *actionEnable_show_point_coordinates;
    QWidget *centralwidget;
    QCustomPlot *plot;
    QGroupBox *groupBox_3;
    QWidget *layoutWidget;
    QGridLayout *gridLayout_6;
    QPushButton *btn_Clean_xy3;
    QPushButton *btn_Clean_xy2;
    QPushButton *btn_Fix_Graph;
    QPushButton *btn_Clean_xy;
    QDoubleSpinBox *x11;
    QDoubleSpinBox *y11;
    QDoubleSpinBox *x12;
    QDoubleSpinBox *y12;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGroupBox *groupBox;
    QWidget *layoutWidget1;
    QGridLayout *gridLayout_9;
    QGridLayout *gridLayout_8;
    QGridLayout *gridLayout_2;
    QLabel *label;
    QDoubleSpinBox *bx_x;
    QGridLayout *gridLayout_5;
    QLabel *label_3;
    QDoubleSpinBox *bx_x2;
    QGridLayout *gridLayout_7;
    QLabel *label_7;
    QDoubleSpinBox *bx_x3;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_2;
    QLabel *label_4;
    QPushButton *btn_add;
    QPushButton *btn_add3;
    QPushButton *btn_Del_R;
    QPushButton *btn_add2;
    QPushButton *btn_Del_G;
    QDoubleSpinBox *bx_y;
    QDoubleSpinBox *bx_y3;
    QDoubleSpinBox *bx_y2;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_8;
    QPushButton *btn_Del_B;
    QSpacerItem *horizontalSpacer_4;
    QWidget *tab_2;
    QGroupBox *grpbx_Bunded;
    QWidget *layoutWidget2;
    QGridLayout *gridLayout_13;
    QGridLayout *gridLayout_3;
    QLabel *label_15;
    QLabel *label_16;
    QSpinBox *bx_y3_range1;
    QSpinBox *bx_x_range2;
    QSpinBox *bx_x2_range1;
    QSpinBox *bx_y2_range2;
    QSpinBox *bx_y_range1;
    QLabel *label_17;
    QSpinBox *bx_y_range2;
    QSpinBox *bx_y3_range2;
    QLabel *label_20;
    QLabel *label_18;
    QLabel *label_11;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_13;
    QLabel *label_22;
    QLabel *label_12;
    QSpacerItem *horizontalSpacer_6;
    QSpacerItem *horizontalSpacer_3;
    QSpinBox *bx_x3_range2;
    QLabel *label_23;
    QSpinBox *bx_y2_range1;
    QLabel *label_19;
    QSpinBox *bx_x_range1;
    QLabel *label_21;
    QLabel *label_14;
    QSpinBox *bx_x3_range1;
    QSpinBox *bx_x2_range2;
    QSpacerItem *horizontalSpacer_5;
    QGridLayout *gridLayout_12;
    QCheckBox *chb_Zone_Blue;
    QCheckBox *chb_Zone_Green;
    QCheckBox *chb_Zone_Red;
    QCheckBox *chb_Zone_All;
    QLabel *label_31;
    QCheckBox *chb_Bound_Bandom;
    QLabel *label_30;
    QWidget *tab_3;
    QGroupBox *groupBox_5;
    QWidget *layoutWidget3;
    QGridLayout *gridLayout_11;
    QRadioButton *rb_RightClick_Menu;
    QCheckBox *chb_ShowPointCoordinates;
    QCheckBox *chc_EnableMode;
    QSpacerItem *verticalSpacer;
    QCheckBox *chb_ShowBund;
    QRadioButton *rb_RightClick_Editor;
    QCheckBox *chb_Distance;
    QGroupBox *groupBox_4;
    QWidget *layoutWidget4;
    QGridLayout *gridLayout_4;
    QComboBox *cbox_StyleLine_Red;
    QSpinBox *cbox_Size_Green;
    QComboBox *cbox_ScatterStyle_Red;
    QSpinBox *cbox_Size_Red;
    QSpinBox *cbox_Size_Blue;
    QComboBox *cbox_StyleLine_Blue;
    QLabel *label_24;
    QComboBox *cbox_ScatterStyle_Blue;
    QLabel *label_26;
    QLabel *label_25;
    QComboBox *cbox_StyleLine_Green;
    QComboBox *cbox_ScatterStyle_Green;
    QLabel *label_29;
    QLabel *label_27;
    QLabel *label_28;
    QGroupBox *groupBox_2;
    QWidget *layoutWidget5;
    QGridLayout *gridLayout_10;
    QLabel *label_5;
    QLabel *label_6;
    QSpinBox *bx_UpdateTime;
    QSpinBox *bx_Num_Node;
    QSpacerItem *horizontalSpacer;
    QPushButton *btn_Start_Stop;
    QMenuBar *menubar;
    QMenu *menuMenu;
    QMenu *menuHide_graphs;
    QMenu *menuClean_graphs;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(971, 966);
        actionRed = new QAction(MainWindow);
        actionRed->setObjectName(QString::fromUtf8("actionRed"));
        actionRed->setCheckable(true);
        actionRed->setChecked(true);
        actionGreen = new QAction(MainWindow);
        actionGreen->setObjectName(QString::fromUtf8("actionGreen"));
        actionGreen->setCheckable(true);
        actionGreen->setChecked(true);
        actionBlue = new QAction(MainWindow);
        actionBlue->setObjectName(QString::fromUtf8("actionBlue"));
        actionBlue->setCheckable(true);
        actionBlue->setChecked(true);
        actionAll_graphs = new QAction(MainWindow);
        actionAll_graphs->setObjectName(QString::fromUtf8("actionAll_graphs"));
        actionAll_graphs->setCheckable(true);
        actionAll_graphs->setChecked(true);
        actionFix_bound_or_randome_range = new QAction(MainWindow);
        actionFix_bound_or_randome_range->setObjectName(QString::fromUtf8("actionFix_bound_or_randome_range"));
        actionFix_bound_or_randome_range->setCheckable(true);
        actionEnable_selection_mode = new QAction(MainWindow);
        actionEnable_selection_mode->setObjectName(QString::fromUtf8("actionEnable_selection_mode"));
        actionEnable_selection_mode->setCheckable(true);
        actionALL_graphs = new QAction(MainWindow);
        actionALL_graphs->setObjectName(QString::fromUtf8("actionALL_graphs"));
        actionFix_grapgs = new QAction(MainWindow);
        actionFix_grapgs->setObjectName(QString::fromUtf8("actionFix_grapgs"));
        actionRed_Cleen = new QAction(MainWindow);
        actionRed_Cleen->setObjectName(QString::fromUtf8("actionRed_Cleen"));
        actionGreen_Cean = new QAction(MainWindow);
        actionGreen_Cean->setObjectName(QString::fromUtf8("actionGreen_Cean"));
        actionBlue_Cleen = new QAction(MainWindow);
        actionBlue_Cleen->setObjectName(QString::fromUtf8("actionBlue_Cleen"));
        actionAll_Graphs_Clean = new QAction(MainWindow);
        actionAll_Graphs_Clean->setObjectName(QString::fromUtf8("actionAll_Graphs_Clean"));
        actionStart_stop = new QAction(MainWindow);
        actionStart_stop->setObjectName(QString::fromUtf8("actionStart_stop"));
        actionStart_stop->setCheckable(true);
        actionEnable_show_point_coordinates = new QAction(MainWindow);
        actionEnable_show_point_coordinates->setObjectName(QString::fromUtf8("actionEnable_show_point_coordinates"));
        actionEnable_show_point_coordinates->setCheckable(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        plot = new QCustomPlot(centralwidget);
        plot->setObjectName(QString::fromUtf8("plot"));
        plot->setGeometry(QRect(20, 20, 741, 501));
        groupBox_3 = new QGroupBox(centralwidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(800, 20, 161, 861));
        layoutWidget = new QWidget(groupBox_3);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 21, 143, 206));
        gridLayout_6 = new QGridLayout(layoutWidget);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        gridLayout_6->setContentsMargins(0, 0, 0, 0);
        btn_Clean_xy3 = new QPushButton(layoutWidget);
        btn_Clean_xy3->setObjectName(QString::fromUtf8("btn_Clean_xy3"));
        btn_Clean_xy3->setAutoDefault(true);

        gridLayout_6->addWidget(btn_Clean_xy3, 2, 0, 1, 1);

        btn_Clean_xy2 = new QPushButton(layoutWidget);
        btn_Clean_xy2->setObjectName(QString::fromUtf8("btn_Clean_xy2"));
        btn_Clean_xy2->setAutoDefault(true);

        gridLayout_6->addWidget(btn_Clean_xy2, 1, 0, 1, 1);

        btn_Fix_Graph = new QPushButton(layoutWidget);
        btn_Fix_Graph->setObjectName(QString::fromUtf8("btn_Fix_Graph"));
        btn_Fix_Graph->setAutoDefault(true);

        gridLayout_6->addWidget(btn_Fix_Graph, 3, 0, 1, 1);

        btn_Clean_xy = new QPushButton(layoutWidget);
        btn_Clean_xy->setObjectName(QString::fromUtf8("btn_Clean_xy"));
        btn_Clean_xy->setAutoDefault(true);

        gridLayout_6->addWidget(btn_Clean_xy, 0, 0, 1, 1);

        x11 = new QDoubleSpinBox(groupBox_3);
        x11->setObjectName(QString::fromUtf8("x11"));
        x11->setGeometry(QRect(10, 250, 63, 26));
        y11 = new QDoubleSpinBox(groupBox_3);
        y11->setObjectName(QString::fromUtf8("y11"));
        y11->setGeometry(QRect(90, 250, 63, 26));
        x12 = new QDoubleSpinBox(groupBox_3);
        x12->setObjectName(QString::fromUtf8("x12"));
        x12->setGeometry(QRect(10, 280, 63, 26));
        y12 = new QDoubleSpinBox(groupBox_3);
        y12->setObjectName(QString::fromUtf8("y12"));
        y12->setGeometry(QRect(90, 280, 63, 26));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(20, 568, 771, 261));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        groupBox = new QGroupBox(tab);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(10, 10, 721, 171));
        layoutWidget1 = new QWidget(groupBox);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(20, 23, 591, 124));
        gridLayout_9 = new QGridLayout(layoutWidget1);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        gridLayout_9->setContentsMargins(0, 0, 0, 0);
        gridLayout_8 = new QGridLayout();
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label = new QLabel(layoutWidget1);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_2->addWidget(label, 0, 0, 1, 1);


        gridLayout_8->addLayout(gridLayout_2, 0, 0, 1, 1);

        bx_x = new QDoubleSpinBox(layoutWidget1);
        bx_x->setObjectName(QString::fromUtf8("bx_x"));
        bx_x->setMinimum(-999999.000000000000000);
        bx_x->setMaximum(999999.000000000000000);
        bx_x->setValue(0.000000000000000);

        gridLayout_8->addWidget(bx_x, 0, 1, 1, 1);

        gridLayout_5 = new QGridLayout();
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_5->addWidget(label_3, 0, 0, 1, 1);


        gridLayout_8->addLayout(gridLayout_5, 1, 0, 1, 1);

        bx_x2 = new QDoubleSpinBox(layoutWidget1);
        bx_x2->setObjectName(QString::fromUtf8("bx_x2"));
        bx_x2->setMinimum(-99999.000000000000000);
        bx_x2->setMaximum(99999.000000000000000);

        gridLayout_8->addWidget(bx_x2, 1, 1, 1, 1);

        gridLayout_7 = new QGridLayout();
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        label_7 = new QLabel(layoutWidget1);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_7->addWidget(label_7, 0, 0, 1, 1);


        gridLayout_8->addLayout(gridLayout_7, 2, 0, 1, 1);

        bx_x3 = new QDoubleSpinBox(layoutWidget1);
        bx_x3->setObjectName(QString::fromUtf8("bx_x3"));
        bx_x3->setMinimum(-99999.000000000000000);
        bx_x3->setMaximum(99999.000000000000000);

        gridLayout_8->addWidget(bx_x3, 2, 1, 1, 1);


        gridLayout_9->addLayout(gridLayout_8, 0, 0, 1, 1);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_3->addWidget(label_2);

        label_4 = new QLabel(layoutWidget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_3->addWidget(label_4);


        gridLayout->addLayout(verticalLayout_3, 0, 0, 2, 1);

        btn_add = new QPushButton(layoutWidget1);
        btn_add->setObjectName(QString::fromUtf8("btn_add"));
        btn_add->setAutoDefault(true);

        gridLayout->addWidget(btn_add, 0, 3, 1, 1);

        btn_add3 = new QPushButton(layoutWidget1);
        btn_add3->setObjectName(QString::fromUtf8("btn_add3"));
        btn_add3->setAutoDefault(true);

        gridLayout->addWidget(btn_add3, 2, 3, 1, 1);

        btn_Del_R = new QPushButton(layoutWidget1);
        btn_Del_R->setObjectName(QString::fromUtf8("btn_Del_R"));

        gridLayout->addWidget(btn_Del_R, 0, 5, 1, 1);

        btn_add2 = new QPushButton(layoutWidget1);
        btn_add2->setObjectName(QString::fromUtf8("btn_add2"));
        btn_add2->setAutoDefault(true);

        gridLayout->addWidget(btn_add2, 1, 3, 1, 1);

        btn_Del_G = new QPushButton(layoutWidget1);
        btn_Del_G->setObjectName(QString::fromUtf8("btn_Del_G"));

        gridLayout->addWidget(btn_Del_G, 1, 5, 1, 1);

        bx_y = new QDoubleSpinBox(layoutWidget1);
        bx_y->setObjectName(QString::fromUtf8("bx_y"));
        bx_y->setMinimum(-999999.000000000000000);
        bx_y->setMaximum(999999.000000000000000);
        bx_y->setValue(0.000000000000000);

        gridLayout->addWidget(bx_y, 0, 1, 1, 1);

        bx_y3 = new QDoubleSpinBox(layoutWidget1);
        bx_y3->setObjectName(QString::fromUtf8("bx_y3"));
        bx_y3->setMinimum(-99999.000000000000000);
        bx_y3->setMaximum(99999.000000000000000);

        gridLayout->addWidget(bx_y3, 2, 1, 1, 1);

        bx_y2 = new QDoubleSpinBox(layoutWidget1);
        bx_y2->setObjectName(QString::fromUtf8("bx_y2"));
        bx_y2->setMinimum(-99999.000000000000000);
        bx_y2->setMaximum(99999.000000000000000);

        gridLayout->addWidget(bx_y2, 1, 1, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 1, 2, 1, 1);

        label_8 = new QLabel(layoutWidget1);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout->addWidget(label_8, 2, 0, 1, 1);

        btn_Del_B = new QPushButton(layoutWidget1);
        btn_Del_B->setObjectName(QString::fromUtf8("btn_Del_B"));

        gridLayout->addWidget(btn_Del_B, 2, 5, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_4, 1, 4, 1, 1);


        gridLayout_9->addLayout(gridLayout, 0, 1, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        grpbx_Bunded = new QGroupBox(tab_2);
        grpbx_Bunded->setObjectName(QString::fromUtf8("grpbx_Bunded"));
        grpbx_Bunded->setGeometry(QRect(10, 30, 721, 161));
        layoutWidget2 = new QWidget(grpbx_Bunded);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(10, 35, 681, 118));
        gridLayout_13 = new QGridLayout(layoutWidget2);
        gridLayout_13->setObjectName(QString::fromUtf8("gridLayout_13"));
        gridLayout_13->setContentsMargins(0, 0, 0, 0);
        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_15 = new QLabel(layoutWidget2);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        gridLayout_3->addWidget(label_15, 2, 4, 1, 1);

        label_16 = new QLabel(layoutWidget2);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        gridLayout_3->addWidget(label_16, 0, 4, 1, 1);

        bx_y3_range1 = new QSpinBox(layoutWidget2);
        bx_y3_range1->setObjectName(QString::fromUtf8("bx_y3_range1"));
        bx_y3_range1->setMinimum(-999999);
        bx_y3_range1->setMaximum(999999);

        gridLayout_3->addWidget(bx_y3_range1, 2, 8, 1, 1);

        bx_x_range2 = new QSpinBox(layoutWidget2);
        bx_x_range2->setObjectName(QString::fromUtf8("bx_x_range2"));
        bx_x_range2->setMinimum(-999999);
        bx_x_range2->setMaximum(999999);

        gridLayout_3->addWidget(bx_x_range2, 0, 5, 1, 1);

        bx_x2_range1 = new QSpinBox(layoutWidget2);
        bx_x2_range1->setObjectName(QString::fromUtf8("bx_x2_range1"));
        bx_x2_range1->setMinimum(-999999);
        bx_x2_range1->setMaximum(999999);

        gridLayout_3->addWidget(bx_x2_range1, 1, 3, 1, 1);

        bx_y2_range2 = new QSpinBox(layoutWidget2);
        bx_y2_range2->setObjectName(QString::fromUtf8("bx_y2_range2"));
        bx_y2_range2->setMinimum(-999999);
        bx_y2_range2->setMaximum(999999);

        gridLayout_3->addWidget(bx_y2_range2, 1, 11, 1, 1);

        bx_y_range1 = new QSpinBox(layoutWidget2);
        bx_y_range1->setObjectName(QString::fromUtf8("bx_y_range1"));
        bx_y_range1->setMinimum(-999999);
        bx_y_range1->setMaximum(999999);

        gridLayout_3->addWidget(bx_y_range1, 0, 8, 1, 1);

        label_17 = new QLabel(layoutWidget2);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        gridLayout_3->addWidget(label_17, 1, 4, 1, 1);

        bx_y_range2 = new QSpinBox(layoutWidget2);
        bx_y_range2->setObjectName(QString::fromUtf8("bx_y_range2"));
        bx_y_range2->setMinimum(-999999);
        bx_y_range2->setMaximum(999999);

        gridLayout_3->addWidget(bx_y_range2, 0, 11, 1, 1);

        bx_y3_range2 = new QSpinBox(layoutWidget2);
        bx_y3_range2->setObjectName(QString::fromUtf8("bx_y3_range2"));
        bx_y3_range2->setMinimum(-999999);
        bx_y3_range2->setMaximum(999999);

        gridLayout_3->addWidget(bx_y3_range2, 2, 11, 1, 1);

        label_20 = new QLabel(layoutWidget2);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout_3->addWidget(label_20, 1, 10, 1, 1);

        label_18 = new QLabel(layoutWidget2);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        gridLayout_3->addWidget(label_18, 2, 7, 1, 1);

        label_11 = new QLabel(layoutWidget2);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout_3->addWidget(label_11, 2, 0, 1, 1);

        label_9 = new QLabel(layoutWidget2);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout_3->addWidget(label_9, 0, 0, 1, 1);

        label_10 = new QLabel(layoutWidget2);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout_3->addWidget(label_10, 1, 0, 1, 1);

        label_13 = new QLabel(layoutWidget2);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        gridLayout_3->addWidget(label_13, 1, 2, 1, 1);

        label_22 = new QLabel(layoutWidget2);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        gridLayout_3->addWidget(label_22, 2, 10, 1, 1);

        label_12 = new QLabel(layoutWidget2);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayout_3->addWidget(label_12, 0, 2, 1, 1);

        horizontalSpacer_6 = new QSpacerItem(38, 16, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_6, 1, 6, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_3, 1, 1, 1, 1);

        bx_x3_range2 = new QSpinBox(layoutWidget2);
        bx_x3_range2->setObjectName(QString::fromUtf8("bx_x3_range2"));
        bx_x3_range2->setMinimum(-999999);
        bx_x3_range2->setMaximum(999999);

        gridLayout_3->addWidget(bx_x3_range2, 2, 5, 1, 1);

        label_23 = new QLabel(layoutWidget2);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        gridLayout_3->addWidget(label_23, 0, 10, 1, 1);

        bx_y2_range1 = new QSpinBox(layoutWidget2);
        bx_y2_range1->setObjectName(QString::fromUtf8("bx_y2_range1"));
        bx_y2_range1->setMinimum(-999999);
        bx_y2_range1->setMaximum(999999);

        gridLayout_3->addWidget(bx_y2_range1, 1, 8, 1, 1);

        label_19 = new QLabel(layoutWidget2);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        gridLayout_3->addWidget(label_19, 0, 7, 1, 1);

        bx_x_range1 = new QSpinBox(layoutWidget2);
        bx_x_range1->setObjectName(QString::fromUtf8("bx_x_range1"));
        bx_x_range1->setMinimum(-999999);
        bx_x_range1->setMaximum(999999);

        gridLayout_3->addWidget(bx_x_range1, 0, 3, 1, 1);

        label_21 = new QLabel(layoutWidget2);
        label_21->setObjectName(QString::fromUtf8("label_21"));

        gridLayout_3->addWidget(label_21, 1, 7, 1, 1);

        label_14 = new QLabel(layoutWidget2);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        gridLayout_3->addWidget(label_14, 2, 2, 1, 1);

        bx_x3_range1 = new QSpinBox(layoutWidget2);
        bx_x3_range1->setObjectName(QString::fromUtf8("bx_x3_range1"));
        bx_x3_range1->setMinimum(-999999);
        bx_x3_range1->setMaximum(999999);

        gridLayout_3->addWidget(bx_x3_range1, 2, 3, 1, 1);

        bx_x2_range2 = new QSpinBox(layoutWidget2);
        bx_x2_range2->setObjectName(QString::fromUtf8("bx_x2_range2"));
        bx_x2_range2->setMinimum(-999999);
        bx_x2_range2->setMaximum(999999);

        gridLayout_3->addWidget(bx_x2_range2, 1, 5, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_5, 1, 12, 1, 1);


        gridLayout_13->addLayout(gridLayout_3, 0, 0, 1, 1);

        gridLayout_12 = new QGridLayout();
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        chb_Zone_Blue = new QCheckBox(layoutWidget2);
        chb_Zone_Blue->setObjectName(QString::fromUtf8("chb_Zone_Blue"));

        gridLayout_12->addWidget(chb_Zone_Blue, 2, 0, 1, 1);

        chb_Zone_Green = new QCheckBox(layoutWidget2);
        chb_Zone_Green->setObjectName(QString::fromUtf8("chb_Zone_Green"));

        gridLayout_12->addWidget(chb_Zone_Green, 1, 0, 1, 1);

        chb_Zone_Red = new QCheckBox(layoutWidget2);
        chb_Zone_Red->setObjectName(QString::fromUtf8("chb_Zone_Red"));

        gridLayout_12->addWidget(chb_Zone_Red, 0, 0, 1, 1);


        gridLayout_13->addLayout(gridLayout_12, 0, 1, 1, 1);

        chb_Zone_All = new QCheckBox(grpbx_Bunded);
        chb_Zone_All->setObjectName(QString::fromUtf8("chb_Zone_All"));
        chb_Zone_All->setGeometry(QRect(661, 10, 21, 18));
        label_31 = new QLabel(grpbx_Bunded);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        label_31->setGeometry(QRect(630, 11, 21, 16));
        chb_Bound_Bandom = new QCheckBox(tab_2);
        chb_Bound_Bandom->setObjectName(QString::fromUtf8("chb_Bound_Bandom"));
        chb_Bound_Bandom->setGeometry(QRect(10, 10, 231, 18));
        chb_Bound_Bandom->setChecked(true);
        label_30 = new QLabel(tab_2);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setGeometry(QRect(680, 10, 31, 16));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        groupBox_5 = new QGroupBox(tab_3);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setGeometry(QRect(510, 10, 261, 211));
        layoutWidget3 = new QWidget(groupBox_5);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(11, 10, 236, 182));
        gridLayout_11 = new QGridLayout(layoutWidget3);
        gridLayout_11->setObjectName(QString::fromUtf8("gridLayout_11"));
        gridLayout_11->setContentsMargins(0, 0, 0, 0);
        rb_RightClick_Menu = new QRadioButton(layoutWidget3);
        rb_RightClick_Menu->setObjectName(QString::fromUtf8("rb_RightClick_Menu"));

        gridLayout_11->addWidget(rb_RightClick_Menu, 5, 0, 1, 1);

        chb_ShowPointCoordinates = new QCheckBox(layoutWidget3);
        chb_ShowPointCoordinates->setObjectName(QString::fromUtf8("chb_ShowPointCoordinates"));

        gridLayout_11->addWidget(chb_ShowPointCoordinates, 1, 0, 1, 1);

        chc_EnableMode = new QCheckBox(layoutWidget3);
        chc_EnableMode->setObjectName(QString::fromUtf8("chc_EnableMode"));
        chc_EnableMode->setEnabled(true);
        chc_EnableMode->setCheckable(true);
        chc_EnableMode->setChecked(false);

        gridLayout_11->addWidget(chc_EnableMode, 0, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_11->addItem(verticalSpacer, 3, 0, 1, 1);

        chb_ShowBund = new QCheckBox(layoutWidget3);
        chb_ShowBund->setObjectName(QString::fromUtf8("chb_ShowBund"));

        gridLayout_11->addWidget(chb_ShowBund, 2, 0, 1, 1);

        rb_RightClick_Editor = new QRadioButton(layoutWidget3);
        rb_RightClick_Editor->setObjectName(QString::fromUtf8("rb_RightClick_Editor"));
        rb_RightClick_Editor->setChecked(true);

        gridLayout_11->addWidget(rb_RightClick_Editor, 6, 0, 1, 1);

        chb_Distance = new QCheckBox(layoutWidget3);
        chb_Distance->setObjectName(QString::fromUtf8("chb_Distance"));

        gridLayout_11->addWidget(chb_Distance, 4, 0, 1, 1);

        groupBox_4 = new QGroupBox(tab_3);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(10, 10, 491, 211));
        layoutWidget4 = new QWidget(groupBox_4);
        layoutWidget4->setObjectName(QString::fromUtf8("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(11, 31, 451, 121));
        gridLayout_4 = new QGridLayout(layoutWidget4);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        cbox_StyleLine_Red = new QComboBox(layoutWidget4);
        cbox_StyleLine_Red->addItem(QString());
        cbox_StyleLine_Red->addItem(QString());
        cbox_StyleLine_Red->addItem(QString());
        cbox_StyleLine_Red->addItem(QString());
        cbox_StyleLine_Red->addItem(QString());
        cbox_StyleLine_Red->addItem(QString());
        cbox_StyleLine_Red->setObjectName(QString::fromUtf8("cbox_StyleLine_Red"));

        gridLayout_4->addWidget(cbox_StyleLine_Red, 0, 2, 1, 1);

        cbox_Size_Green = new QSpinBox(layoutWidget4);
        cbox_Size_Green->setObjectName(QString::fromUtf8("cbox_Size_Green"));
        cbox_Size_Green->setMaximum(30);
        cbox_Size_Green->setValue(6);

        gridLayout_4->addWidget(cbox_Size_Green, 1, 3, 1, 1);

        cbox_ScatterStyle_Red = new QComboBox(layoutWidget4);
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->addItem(QString());
        cbox_ScatterStyle_Red->setObjectName(QString::fromUtf8("cbox_ScatterStyle_Red"));

        gridLayout_4->addWidget(cbox_ScatterStyle_Red, 0, 1, 1, 1);

        cbox_Size_Red = new QSpinBox(layoutWidget4);
        cbox_Size_Red->setObjectName(QString::fromUtf8("cbox_Size_Red"));
        cbox_Size_Red->setMaximum(30);
        cbox_Size_Red->setValue(6);

        gridLayout_4->addWidget(cbox_Size_Red, 0, 3, 1, 1);

        cbox_Size_Blue = new QSpinBox(layoutWidget4);
        cbox_Size_Blue->setObjectName(QString::fromUtf8("cbox_Size_Blue"));
        cbox_Size_Blue->setMaximum(30);
        cbox_Size_Blue->setValue(6);

        gridLayout_4->addWidget(cbox_Size_Blue, 2, 3, 1, 1);

        cbox_StyleLine_Blue = new QComboBox(layoutWidget4);
        cbox_StyleLine_Blue->addItem(QString());
        cbox_StyleLine_Blue->addItem(QString());
        cbox_StyleLine_Blue->addItem(QString());
        cbox_StyleLine_Blue->addItem(QString());
        cbox_StyleLine_Blue->addItem(QString());
        cbox_StyleLine_Blue->addItem(QString());
        cbox_StyleLine_Blue->setObjectName(QString::fromUtf8("cbox_StyleLine_Blue"));

        gridLayout_4->addWidget(cbox_StyleLine_Blue, 2, 2, 1, 1);

        label_24 = new QLabel(layoutWidget4);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        gridLayout_4->addWidget(label_24, 2, 0, 1, 1);

        cbox_ScatterStyle_Blue = new QComboBox(layoutWidget4);
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->addItem(QString());
        cbox_ScatterStyle_Blue->setObjectName(QString::fromUtf8("cbox_ScatterStyle_Blue"));

        gridLayout_4->addWidget(cbox_ScatterStyle_Blue, 2, 1, 1, 1);

        label_26 = new QLabel(layoutWidget4);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        gridLayout_4->addWidget(label_26, 1, 0, 1, 1);

        label_25 = new QLabel(layoutWidget4);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        gridLayout_4->addWidget(label_25, 0, 0, 1, 1);

        cbox_StyleLine_Green = new QComboBox(layoutWidget4);
        cbox_StyleLine_Green->addItem(QString());
        cbox_StyleLine_Green->addItem(QString());
        cbox_StyleLine_Green->addItem(QString());
        cbox_StyleLine_Green->addItem(QString());
        cbox_StyleLine_Green->addItem(QString());
        cbox_StyleLine_Green->addItem(QString());
        cbox_StyleLine_Green->setObjectName(QString::fromUtf8("cbox_StyleLine_Green"));

        gridLayout_4->addWidget(cbox_StyleLine_Green, 1, 2, 1, 1);

        cbox_ScatterStyle_Green = new QComboBox(layoutWidget4);
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->addItem(QString());
        cbox_ScatterStyle_Green->setObjectName(QString::fromUtf8("cbox_ScatterStyle_Green"));

        gridLayout_4->addWidget(cbox_ScatterStyle_Green, 1, 1, 1, 1);

        label_29 = new QLabel(groupBox_4);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setGeometry(QRect(400, 11, 61, 16));
        label_27 = new QLabel(groupBox_4);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(130, 11, 101, 16));
        label_28 = new QLabel(groupBox_4);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setGeometry(QRect(270, 11, 81, 16));
        tabWidget->addTab(tab_3, QString());
        groupBox_2 = new QGroupBox(centralwidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(20, 830, 771, 81));
        layoutWidget5 = new QWidget(groupBox_2);
        layoutWidget5->setObjectName(QString::fromUtf8("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(10, 30, 441, 36));
        gridLayout_10 = new QGridLayout(layoutWidget5);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        gridLayout_10->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget5);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_10->addWidget(label_5, 0, 0, 1, 1);

        label_6 = new QLabel(layoutWidget5);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_10->addWidget(label_6, 0, 3, 1, 1);

        bx_UpdateTime = new QSpinBox(layoutWidget5);
        bx_UpdateTime->setObjectName(QString::fromUtf8("bx_UpdateTime"));

        gridLayout_10->addWidget(bx_UpdateTime, 0, 4, 1, 1);

        bx_Num_Node = new QSpinBox(layoutWidget5);
        bx_Num_Node->setObjectName(QString::fromUtf8("bx_Num_Node"));
        bx_Num_Node->setMaximum(999999);
        bx_Num_Node->setValue(20);

        gridLayout_10->addWidget(bx_Num_Node, 0, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_10->addItem(horizontalSpacer, 0, 2, 1, 1);

        btn_Start_Stop = new QPushButton(groupBox_2);
        btn_Start_Stop->setObjectName(QString::fromUtf8("btn_Start_Stop"));
        btn_Start_Stop->setGeometry(QRect(540, 29, 181, 41));
        btn_Start_Stop->setCheckable(true);
        btn_Start_Stop->setAutoDefault(true);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 971, 32));
        menuMenu = new QMenu(menubar);
        menuMenu->setObjectName(QString::fromUtf8("menuMenu"));
        menuHide_graphs = new QMenu(menuMenu);
        menuHide_graphs->setObjectName(QString::fromUtf8("menuHide_graphs"));
        menuHide_graphs->setLayoutDirection(Qt::LeftToRight);
        menuClean_graphs = new QMenu(menuMenu);
        menuClean_graphs->setObjectName(QString::fromUtf8("menuClean_graphs"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
        QWidget::setTabOrder(bx_x, bx_y);
        QWidget::setTabOrder(bx_y, btn_add);
        QWidget::setTabOrder(btn_add, btn_Del_R);
        QWidget::setTabOrder(btn_Del_R, bx_x2);
        QWidget::setTabOrder(bx_x2, bx_y2);
        QWidget::setTabOrder(bx_y2, btn_add2);
        QWidget::setTabOrder(btn_add2, btn_Del_G);
        QWidget::setTabOrder(btn_Del_G, bx_x3);
        QWidget::setTabOrder(bx_x3, bx_y3);
        QWidget::setTabOrder(bx_y3, btn_add3);
        QWidget::setTabOrder(btn_add3, btn_Del_B);
        QWidget::setTabOrder(btn_Del_B, bx_x_range1);
        QWidget::setTabOrder(bx_x_range1, bx_x_range2);
        QWidget::setTabOrder(bx_x_range2, bx_y_range1);
        QWidget::setTabOrder(bx_y_range1, bx_y_range2);
        QWidget::setTabOrder(bx_y_range2, bx_x2_range1);
        QWidget::setTabOrder(bx_x2_range1, bx_x2_range2);
        QWidget::setTabOrder(bx_x2_range2, bx_y2_range1);
        QWidget::setTabOrder(bx_y2_range1, bx_y2_range2);
        QWidget::setTabOrder(bx_y2_range2, bx_x3_range1);
        QWidget::setTabOrder(bx_x3_range1, bx_x3_range2);
        QWidget::setTabOrder(bx_x3_range2, bx_y3_range1);
        QWidget::setTabOrder(bx_y3_range1, bx_y3_range2);
        QWidget::setTabOrder(bx_y3_range2, bx_Num_Node);
        QWidget::setTabOrder(bx_Num_Node, bx_UpdateTime);
        QWidget::setTabOrder(bx_UpdateTime, btn_Start_Stop);
        QWidget::setTabOrder(btn_Start_Stop, tabWidget);
        QWidget::setTabOrder(tabWidget, btn_Clean_xy);
        QWidget::setTabOrder(btn_Clean_xy, chb_Bound_Bandom);
        QWidget::setTabOrder(chb_Bound_Bandom, btn_Clean_xy3);
        QWidget::setTabOrder(btn_Clean_xy3, btn_Fix_Graph);
        QWidget::setTabOrder(btn_Fix_Graph, btn_Clean_xy2);

        menubar->addAction(menuMenu->menuAction());
        menuMenu->addAction(menuHide_graphs->menuAction());
        menuMenu->addAction(menuClean_graphs->menuAction());
        menuMenu->addAction(actionFix_bound_or_randome_range);
        menuMenu->addAction(actionFix_grapgs);
        menuMenu->addSeparator();
        menuMenu->addAction(actionEnable_selection_mode);
        menuMenu->addAction(actionEnable_show_point_coordinates);
        menuMenu->addSeparator();
        menuMenu->addAction(actionStart_stop);
        menuHide_graphs->addSeparator();
        menuHide_graphs->addAction(actionRed);
        menuHide_graphs->addAction(actionGreen);
        menuHide_graphs->addAction(actionBlue);
        menuHide_graphs->addSeparator();
        menuHide_graphs->addAction(actionAll_graphs);
        menuClean_graphs->addAction(actionRed_Cleen);
        menuClean_graphs->addAction(actionGreen_Cean);
        menuClean_graphs->addAction(actionBlue_Cleen);
        menuClean_graphs->addSeparator();
        menuClean_graphs->addAction(actionAll_Graphs_Clean);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(2);
        cbox_ScatterStyle_Red->setCurrentIndex(5);
        cbox_ScatterStyle_Blue->setCurrentIndex(5);
        cbox_ScatterStyle_Green->setCurrentIndex(5);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionRed->setText(QCoreApplication::translate("MainWindow", "Red", nullptr));
#if QT_CONFIG(shortcut)
        actionRed->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+Shift+R", nullptr));
#endif // QT_CONFIG(shortcut)
        actionGreen->setText(QCoreApplication::translate("MainWindow", "Green", nullptr));
#if QT_CONFIG(shortcut)
        actionGreen->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+Shift+G", nullptr));
#endif // QT_CONFIG(shortcut)
        actionBlue->setText(QCoreApplication::translate("MainWindow", "Blue", nullptr));
#if QT_CONFIG(shortcut)
        actionBlue->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+Shift+B", nullptr));
#endif // QT_CONFIG(shortcut)
        actionAll_graphs->setText(QCoreApplication::translate("MainWindow", "All graphs", nullptr));
#if QT_CONFIG(shortcut)
        actionAll_graphs->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+Shift+A", nullptr));
#endif // QT_CONFIG(shortcut)
        actionFix_bound_or_randome_range->setText(QCoreApplication::translate("MainWindow", "Automatically or Manually", nullptr));
        actionEnable_selection_mode->setText(QCoreApplication::translate("MainWindow", "Enable mode near selection", nullptr));
        actionALL_graphs->setText(QCoreApplication::translate("MainWindow", "ALL graphs", nullptr));
        actionFix_grapgs->setText(QCoreApplication::translate("MainWindow", "Fix graphs", nullptr));
        actionRed_Cleen->setText(QCoreApplication::translate("MainWindow", "Red", nullptr));
        actionGreen_Cean->setText(QCoreApplication::translate("MainWindow", "Green", nullptr));
        actionBlue_Cleen->setText(QCoreApplication::translate("MainWindow", "Blue", nullptr));
        actionAll_Graphs_Clean->setText(QCoreApplication::translate("MainWindow", "All Graphs", nullptr));
        actionStart_stop->setText(QCoreApplication::translate("MainWindow", "Start/Stop", nullptr));
#if QT_CONFIG(shortcut)
        actionStart_stop->setShortcut(QCoreApplication::translate("MainWindow", "F11", nullptr));
#endif // QT_CONFIG(shortcut)
        actionEnable_show_point_coordinates->setText(QCoreApplication::translate("MainWindow", "Enable show point coordinates", nullptr));
        groupBox_3->setTitle(QString());
        btn_Clean_xy3->setText(QCoreApplication::translate("MainWindow", "Clean Blue Graph", nullptr));
        btn_Clean_xy2->setText(QCoreApplication::translate("MainWindow", "Clean Green Graph", nullptr));
        btn_Fix_Graph->setText(QCoreApplication::translate("MainWindow", "Graph Fixed", nullptr));
        btn_Clean_xy->setText(QCoreApplication::translate("MainWindow", "Clean Red Graph", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "Add or Delete node point", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Red      X:", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Green  X2:", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Blue    X3:", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Y:", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Y2:", nullptr));
        btn_add->setText(QCoreApplication::translate("MainWindow", "Add", nullptr));
        btn_add3->setText(QCoreApplication::translate("MainWindow", "Add", nullptr));
        btn_Del_R->setText(QCoreApplication::translate("MainWindow", "Delete", nullptr));
        btn_add2->setText(QCoreApplication::translate("MainWindow", "Add", nullptr));
        btn_Del_G->setText(QCoreApplication::translate("MainWindow", "Delete", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Y3:", nullptr));
        btn_Del_B->setText(QCoreApplication::translate("MainWindow", "Delete", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("MainWindow", "Tab 1", nullptr));
        grpbx_Bunded->setTitle(QCoreApplication::translate("MainWindow", "Bounded Range", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "X1:", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "X1:", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "X1:", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "Y1:", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "Y:", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "Blue:", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "Red:", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "Green:", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "X:", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "Y1:", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "X :", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "Y1 :", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "Y:", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "Y:", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "X:", nullptr));
        chb_Zone_Blue->setText(QString());
        chb_Zone_Green->setText(QString());
        chb_Zone_Red->setText(QString());
        chb_Zone_All->setText(QString());
        label_31->setText(QCoreApplication::translate("MainWindow", " all", nullptr));
        chb_Bound_Bandom->setText(QCoreApplication::translate("MainWindow", "Automatically or Manually", nullptr));
        label_30->setText(QCoreApplication::translate("MainWindow", "Zone", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("MainWindow", "Tab 2", nullptr));
        groupBox_5->setTitle(QString());
        rb_RightClick_Menu->setText(QCoreApplication::translate("MainWindow", "Right click menu", nullptr));
        chb_ShowPointCoordinates->setText(QCoreApplication::translate("MainWindow", "Enable show point coordinates", nullptr));
        chc_EnableMode->setText(QCoreApplication::translate("MainWindow", "Enable mode near selection", nullptr));
        chb_ShowBund->setText(QCoreApplication::translate("MainWindow", "Enable Show Bund", nullptr));
        rb_RightClick_Editor->setText(QCoreApplication::translate("MainWindow", "Right Click editor", nullptr));
        chb_Distance->setText(QCoreApplication::translate("MainWindow", "Distance", nullptr));
        groupBox_4->setTitle(QString());
        cbox_StyleLine_Red->setItemText(0, QCoreApplication::translate("MainWindow", "None", nullptr));
        cbox_StyleLine_Red->setItemText(1, QCoreApplication::translate("MainWindow", "Line", nullptr));
        cbox_StyleLine_Red->setItemText(2, QCoreApplication::translate("MainWindow", "Step Left ", nullptr));
        cbox_StyleLine_Red->setItemText(3, QCoreApplication::translate("MainWindow", "Step Right", nullptr));
        cbox_StyleLine_Red->setItemText(4, QCoreApplication::translate("MainWindow", "Step Center", nullptr));
        cbox_StyleLine_Red->setItemText(5, QCoreApplication::translate("MainWindow", "Impulse", nullptr));

        cbox_ScatterStyle_Red->setItemText(0, QCoreApplication::translate("MainWindow", "None", nullptr));
        cbox_ScatterStyle_Red->setItemText(1, QCoreApplication::translate("MainWindow", "Dot", nullptr));
        cbox_ScatterStyle_Red->setItemText(2, QCoreApplication::translate("MainWindow", "Cross", nullptr));
        cbox_ScatterStyle_Red->setItemText(3, QCoreApplication::translate("MainWindow", "Plus", nullptr));
        cbox_ScatterStyle_Red->setItemText(4, QCoreApplication::translate("MainWindow", "Circle", nullptr));
        cbox_ScatterStyle_Red->setItemText(5, QCoreApplication::translate("MainWindow", "Disc", nullptr));
        cbox_ScatterStyle_Red->setItemText(6, QCoreApplication::translate("MainWindow", "Square", nullptr));
        cbox_ScatterStyle_Red->setItemText(7, QCoreApplication::translate("MainWindow", "Diamond", nullptr));
        cbox_ScatterStyle_Red->setItemText(8, QCoreApplication::translate("MainWindow", "Star", nullptr));
        cbox_ScatterStyle_Red->setItemText(9, QCoreApplication::translate("MainWindow", "Triangle", nullptr));
        cbox_ScatterStyle_Red->setItemText(10, QCoreApplication::translate("MainWindow", "Triangle Inverted ", nullptr));
        cbox_ScatterStyle_Red->setItemText(11, QCoreApplication::translate("MainWindow", "Cross Square", nullptr));
        cbox_ScatterStyle_Red->setItemText(12, QCoreApplication::translate("MainWindow", "PlusSquare", nullptr));
        cbox_ScatterStyle_Red->setItemText(13, QCoreApplication::translate("MainWindow", "CrossCircle", nullptr));
        cbox_ScatterStyle_Red->setItemText(14, QCoreApplication::translate("MainWindow", "PlusCircle ", nullptr));
        cbox_ScatterStyle_Red->setItemText(15, QCoreApplication::translate("MainWindow", "Peace", nullptr));
        cbox_ScatterStyle_Red->setItemText(16, QCoreApplication::translate("MainWindow", "Pixmap", nullptr));

        cbox_StyleLine_Blue->setItemText(0, QCoreApplication::translate("MainWindow", "None", nullptr));
        cbox_StyleLine_Blue->setItemText(1, QCoreApplication::translate("MainWindow", "Line", nullptr));
        cbox_StyleLine_Blue->setItemText(2, QCoreApplication::translate("MainWindow", "Step Left ", nullptr));
        cbox_StyleLine_Blue->setItemText(3, QCoreApplication::translate("MainWindow", "Step Right", nullptr));
        cbox_StyleLine_Blue->setItemText(4, QCoreApplication::translate("MainWindow", "Step Center", nullptr));
        cbox_StyleLine_Blue->setItemText(5, QCoreApplication::translate("MainWindow", "Impulse", nullptr));

        label_24->setText(QCoreApplication::translate("MainWindow", "Blue:", nullptr));
        cbox_ScatterStyle_Blue->setItemText(0, QCoreApplication::translate("MainWindow", "None", nullptr));
        cbox_ScatterStyle_Blue->setItemText(1, QCoreApplication::translate("MainWindow", "Dot", nullptr));
        cbox_ScatterStyle_Blue->setItemText(2, QCoreApplication::translate("MainWindow", "Cross", nullptr));
        cbox_ScatterStyle_Blue->setItemText(3, QCoreApplication::translate("MainWindow", "Plus", nullptr));
        cbox_ScatterStyle_Blue->setItemText(4, QCoreApplication::translate("MainWindow", "Circle", nullptr));
        cbox_ScatterStyle_Blue->setItemText(5, QCoreApplication::translate("MainWindow", "Disc", nullptr));
        cbox_ScatterStyle_Blue->setItemText(6, QCoreApplication::translate("MainWindow", "Square", nullptr));
        cbox_ScatterStyle_Blue->setItemText(7, QCoreApplication::translate("MainWindow", "Diamond", nullptr));
        cbox_ScatterStyle_Blue->setItemText(8, QCoreApplication::translate("MainWindow", "Star", nullptr));
        cbox_ScatterStyle_Blue->setItemText(9, QCoreApplication::translate("MainWindow", "Triangle", nullptr));
        cbox_ScatterStyle_Blue->setItemText(10, QCoreApplication::translate("MainWindow", "Triangle Inverted ", nullptr));
        cbox_ScatterStyle_Blue->setItemText(11, QCoreApplication::translate("MainWindow", "Cross Square", nullptr));
        cbox_ScatterStyle_Blue->setItemText(12, QCoreApplication::translate("MainWindow", "PlusSquare", nullptr));
        cbox_ScatterStyle_Blue->setItemText(13, QCoreApplication::translate("MainWindow", "CrossCircle", nullptr));
        cbox_ScatterStyle_Blue->setItemText(14, QCoreApplication::translate("MainWindow", "PlusCircle ", nullptr));
        cbox_ScatterStyle_Blue->setItemText(15, QCoreApplication::translate("MainWindow", "Peace", nullptr));
        cbox_ScatterStyle_Blue->setItemText(16, QCoreApplication::translate("MainWindow", "Pixmap", nullptr));

        label_26->setText(QCoreApplication::translate("MainWindow", "Green:", nullptr));
        label_25->setText(QCoreApplication::translate("MainWindow", "Red:", nullptr));
        cbox_StyleLine_Green->setItemText(0, QCoreApplication::translate("MainWindow", "None", nullptr));
        cbox_StyleLine_Green->setItemText(1, QCoreApplication::translate("MainWindow", "Line", nullptr));
        cbox_StyleLine_Green->setItemText(2, QCoreApplication::translate("MainWindow", "Step Left ", nullptr));
        cbox_StyleLine_Green->setItemText(3, QCoreApplication::translate("MainWindow", "Step Right", nullptr));
        cbox_StyleLine_Green->setItemText(4, QCoreApplication::translate("MainWindow", "Step Center", nullptr));
        cbox_StyleLine_Green->setItemText(5, QCoreApplication::translate("MainWindow", "Impulse", nullptr));

        cbox_ScatterStyle_Green->setItemText(0, QCoreApplication::translate("MainWindow", "None", nullptr));
        cbox_ScatterStyle_Green->setItemText(1, QCoreApplication::translate("MainWindow", "Dot", nullptr));
        cbox_ScatterStyle_Green->setItemText(2, QCoreApplication::translate("MainWindow", "Cross", nullptr));
        cbox_ScatterStyle_Green->setItemText(3, QCoreApplication::translate("MainWindow", "Plus", nullptr));
        cbox_ScatterStyle_Green->setItemText(4, QCoreApplication::translate("MainWindow", "Circle", nullptr));
        cbox_ScatterStyle_Green->setItemText(5, QCoreApplication::translate("MainWindow", "Disc", nullptr));
        cbox_ScatterStyle_Green->setItemText(6, QCoreApplication::translate("MainWindow", "Square", nullptr));
        cbox_ScatterStyle_Green->setItemText(7, QCoreApplication::translate("MainWindow", "Diamond", nullptr));
        cbox_ScatterStyle_Green->setItemText(8, QCoreApplication::translate("MainWindow", "Star", nullptr));
        cbox_ScatterStyle_Green->setItemText(9, QCoreApplication::translate("MainWindow", "Triangle", nullptr));
        cbox_ScatterStyle_Green->setItemText(10, QCoreApplication::translate("MainWindow", "Triangle Inverted ", nullptr));
        cbox_ScatterStyle_Green->setItemText(11, QCoreApplication::translate("MainWindow", "Cross Square", nullptr));
        cbox_ScatterStyle_Green->setItemText(12, QCoreApplication::translate("MainWindow", "PlusSquare", nullptr));
        cbox_ScatterStyle_Green->setItemText(13, QCoreApplication::translate("MainWindow", "CrossCircle", nullptr));
        cbox_ScatterStyle_Green->setItemText(14, QCoreApplication::translate("MainWindow", "PlusCircle ", nullptr));
        cbox_ScatterStyle_Green->setItemText(15, QCoreApplication::translate("MainWindow", "Peace", nullptr));
        cbox_ScatterStyle_Green->setItemText(16, QCoreApplication::translate("MainWindow", "Pixmap", nullptr));

        label_29->setText(QCoreApplication::translate("MainWindow", "Size", nullptr));
        label_27->setText(QCoreApplication::translate("MainWindow", "Scatter Style", nullptr));
        label_28->setText(QCoreApplication::translate("MainWindow", "Style Line", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("MainWindow", "Page", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("MainWindow", "Auto Graph ", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Node Counts:", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Update Time:", nullptr));
        bx_UpdateTime->setSuffix(QCoreApplication::translate("MainWindow", "          Sec", nullptr));
        bx_UpdateTime->setPrefix(QString());
        btn_Start_Stop->setText(QCoreApplication::translate("MainWindow", "Start", nullptr));
        menuMenu->setTitle(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        menuHide_graphs->setTitle(QCoreApplication::translate("MainWindow", "Hide graphs", nullptr));
        menuClean_graphs->setTitle(QCoreApplication::translate("MainWindow", "Clean graphs", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
