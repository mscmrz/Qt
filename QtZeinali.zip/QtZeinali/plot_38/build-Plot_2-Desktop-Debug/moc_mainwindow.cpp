/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../plot_44/Plot_2/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[81];
    char stringdata0[2016];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 18), // "on_btn_add_clicked"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 19), // "on_btn_add2_clicked"
QT_MOC_LITERAL(4, 51, 19), // "on_btn_add3_clicked"
QT_MOC_LITERAL(5, 71, 7), // "xyGraph"
QT_MOC_LITERAL(6, 79, 12), // "QMouseEvent*"
QT_MOC_LITERAL(7, 92, 5), // "event"
QT_MOC_LITERAL(8, 98, 23), // "on_btn_Clean_xy_clicked"
QT_MOC_LITERAL(9, 122, 24), // "on_btn_Clean_xy2_clicked"
QT_MOC_LITERAL(10, 147, 24), // "on_btn_Clean_xy3_clicked"
QT_MOC_LITERAL(11, 172, 27), // "on_bx_Num_Node_valueChanged"
QT_MOC_LITERAL(12, 200, 4), // "arg1"
QT_MOC_LITERAL(13, 205, 24), // "on_btn_Fix_Graph_clicked"
QT_MOC_LITERAL(14, 230, 27), // "on_chb_Bound_Bandom_toggled"
QT_MOC_LITERAL(15, 258, 7), // "checked"
QT_MOC_LITERAL(16, 266, 20), // "on_btn_Del_R_clicked"
QT_MOC_LITERAL(17, 287, 20), // "on_btn_Del_G_clicked"
QT_MOC_LITERAL(18, 308, 20), // "on_btn_Del_B_clicked"
QT_MOC_LITERAL(19, 329, 44), // "on_cbox_ScatterStyle_Red_curr..."
QT_MOC_LITERAL(20, 374, 5), // "index"
QT_MOC_LITERAL(21, 380, 46), // "on_cbox_ScatterStyle_Green_cu..."
QT_MOC_LITERAL(22, 427, 45), // "on_cbox_ScatterStyle_Blue_cur..."
QT_MOC_LITERAL(23, 473, 41), // "on_cbox_StyleLine_Red_current..."
QT_MOC_LITERAL(24, 515, 43), // "on_cbox_StyleLine_Green_curre..."
QT_MOC_LITERAL(25, 559, 42), // "on_cbox_StyleLine_Blue_curren..."
QT_MOC_LITERAL(26, 602, 29), // "on_cbox_Size_Red_valueChanged"
QT_MOC_LITERAL(27, 632, 31), // "on_cbox_Size_Green_valueChanged"
QT_MOC_LITERAL(28, 664, 30), // "on_cbox_Size_Blue_valueChanged"
QT_MOC_LITERAL(29, 695, 25), // "on_chc_EnableMode_toggled"
QT_MOC_LITERAL(30, 721, 22), // "on_actionRed_triggered"
QT_MOC_LITERAL(31, 744, 29), // "on_actionAll_graphs_triggered"
QT_MOC_LITERAL(32, 774, 24), // "on_actionGreen_triggered"
QT_MOC_LITERAL(33, 799, 23), // "on_actionBlue_triggered"
QT_MOC_LITERAL(34, 823, 40), // "on_actionEnable_selection_mod..."
QT_MOC_LITERAL(35, 864, 45), // "on_actionFix_bound_or_randome..."
QT_MOC_LITERAL(36, 910, 10), // "graph_Menu"
QT_MOC_LITERAL(37, 921, 29), // "on_actionFix_grapgs_triggered"
QT_MOC_LITERAL(38, 951, 28), // "on_actionRed_Cleen_triggered"
QT_MOC_LITERAL(39, 980, 27), // "actionGreen_Clean_triggered"
QT_MOC_LITERAL(40, 1008, 29), // "on_actionBlue_Cleen_triggered"
QT_MOC_LITERAL(41, 1038, 35), // "on_actionAll_Graphs_Clean_tri..."
QT_MOC_LITERAL(42, 1074, 10), // "moveLegend"
QT_MOC_LITERAL(43, 1085, 35), // "on_chb_ShowPointCoordinates_t..."
QT_MOC_LITERAL(44, 1121, 48), // "on_actionEnable_show_point_co..."
QT_MOC_LITERAL(45, 1170, 29), // "on_actionStart_stop_triggered"
QT_MOC_LITERAL(46, 1200, 25), // "on_btn_Start_Stop_toggled"
QT_MOC_LITERAL(47, 1226, 29), // "on_rb_RightClick_Menu_toggled"
QT_MOC_LITERAL(48, 1256, 31), // "on_rb_RightClick_Editor_toggled"
QT_MOC_LITERAL(49, 1288, 9), // "Zoom_Drag"
QT_MOC_LITERAL(50, 1298, 6), // "rezoom"
QT_MOC_LITERAL(51, 1305, 23), // "on_chb_Zone_Red_toggled"
QT_MOC_LITERAL(52, 1329, 25), // "on_chb_Zone_Green_toggled"
QT_MOC_LITERAL(53, 1355, 24), // "on_chb_Zone_Blue_toggled"
QT_MOC_LITERAL(54, 1380, 17), // "drag_mouseRelease"
QT_MOC_LITERAL(55, 1398, 14), // "drag_mouseMove"
QT_MOC_LITERAL(56, 1413, 15), // "drag_mousePress"
QT_MOC_LITERAL(57, 1429, 9), // "drag_plot"
QT_MOC_LITERAL(58, 1439, 23), // "on_chb_ShowBund_toggled"
QT_MOC_LITERAL(59, 1463, 23), // "on_chb_Zone_All_toggled"
QT_MOC_LITERAL(60, 1487, 13), // "Zone_All_plot"
QT_MOC_LITERAL(61, 1501, 27), // "on_bx_x_range1_valueChanged"
QT_MOC_LITERAL(62, 1529, 27), // "on_bx_x_range2_valueChanged"
QT_MOC_LITERAL(63, 1557, 27), // "on_bx_y_range1_valueChanged"
QT_MOC_LITERAL(64, 1585, 27), // "on_bx_y_range2_valueChanged"
QT_MOC_LITERAL(65, 1613, 28), // "on_bx_x2_range1_valueChanged"
QT_MOC_LITERAL(66, 1642, 28), // "on_bx_x2_range2_valueChanged"
QT_MOC_LITERAL(67, 1671, 28), // "on_bx_y2_range1_valueChanged"
QT_MOC_LITERAL(68, 1700, 28), // "on_bx_y2_range2_valueChanged"
QT_MOC_LITERAL(69, 1729, 28), // "on_bx_x3_range1_valueChanged"
QT_MOC_LITERAL(70, 1758, 28), // "on_bx_x3_range2_valueChanged"
QT_MOC_LITERAL(71, 1787, 28), // "on_bx_y3_range1_valueChanged"
QT_MOC_LITERAL(72, 1816, 28), // "on_bx_y3_range2_valueChanged"
QT_MOC_LITERAL(73, 1845, 18), // "actionRed_Shortkey"
QT_MOC_LITERAL(74, 1864, 20), // "actionGreen_Shortkey"
QT_MOC_LITERAL(75, 1885, 19), // "actionBlue_Shortkey"
QT_MOC_LITERAL(76, 1905, 25), // "actionAll_graphs_Shortkey"
QT_MOC_LITERAL(77, 1931, 23), // "on_chb_Distance_toggled"
QT_MOC_LITERAL(78, 1955, 21), // "distance_mouseRelease"
QT_MOC_LITERAL(79, 1977, 19), // "distance_mousePress"
QT_MOC_LITERAL(80, 1997, 18) // "distance_mouseMove"

    },
    "MainWindow\0on_btn_add_clicked\0\0"
    "on_btn_add2_clicked\0on_btn_add3_clicked\0"
    "xyGraph\0QMouseEvent*\0event\0"
    "on_btn_Clean_xy_clicked\0"
    "on_btn_Clean_xy2_clicked\0"
    "on_btn_Clean_xy3_clicked\0"
    "on_bx_Num_Node_valueChanged\0arg1\0"
    "on_btn_Fix_Graph_clicked\0"
    "on_chb_Bound_Bandom_toggled\0checked\0"
    "on_btn_Del_R_clicked\0on_btn_Del_G_clicked\0"
    "on_btn_Del_B_clicked\0"
    "on_cbox_ScatterStyle_Red_currentIndexChanged\0"
    "index\0on_cbox_ScatterStyle_Green_currentIndexChanged\0"
    "on_cbox_ScatterStyle_Blue_currentIndexChanged\0"
    "on_cbox_StyleLine_Red_currentIndexChanged\0"
    "on_cbox_StyleLine_Green_currentIndexChanged\0"
    "on_cbox_StyleLine_Blue_currentIndexChanged\0"
    "on_cbox_Size_Red_valueChanged\0"
    "on_cbox_Size_Green_valueChanged\0"
    "on_cbox_Size_Blue_valueChanged\0"
    "on_chc_EnableMode_toggled\0"
    "on_actionRed_triggered\0"
    "on_actionAll_graphs_triggered\0"
    "on_actionGreen_triggered\0"
    "on_actionBlue_triggered\0"
    "on_actionEnable_selection_mode_triggered\0"
    "on_actionFix_bound_or_randome_range_triggered\0"
    "graph_Menu\0on_actionFix_grapgs_triggered\0"
    "on_actionRed_Cleen_triggered\0"
    "actionGreen_Clean_triggered\0"
    "on_actionBlue_Cleen_triggered\0"
    "on_actionAll_Graphs_Clean_triggered\0"
    "moveLegend\0on_chb_ShowPointCoordinates_toggled\0"
    "on_actionEnable_show_point_coordinates_triggered\0"
    "on_actionStart_stop_triggered\0"
    "on_btn_Start_Stop_toggled\0"
    "on_rb_RightClick_Menu_toggled\0"
    "on_rb_RightClick_Editor_toggled\0"
    "Zoom_Drag\0rezoom\0on_chb_Zone_Red_toggled\0"
    "on_chb_Zone_Green_toggled\0"
    "on_chb_Zone_Blue_toggled\0drag_mouseRelease\0"
    "drag_mouseMove\0drag_mousePress\0drag_plot\0"
    "on_chb_ShowBund_toggled\0on_chb_Zone_All_toggled\0"
    "Zone_All_plot\0on_bx_x_range1_valueChanged\0"
    "on_bx_x_range2_valueChanged\0"
    "on_bx_y_range1_valueChanged\0"
    "on_bx_y_range2_valueChanged\0"
    "on_bx_x2_range1_valueChanged\0"
    "on_bx_x2_range2_valueChanged\0"
    "on_bx_y2_range1_valueChanged\0"
    "on_bx_y2_range2_valueChanged\0"
    "on_bx_x3_range1_valueChanged\0"
    "on_bx_x3_range2_valueChanged\0"
    "on_bx_y3_range1_valueChanged\0"
    "on_bx_y3_range2_valueChanged\0"
    "actionRed_Shortkey\0actionGreen_Shortkey\0"
    "actionBlue_Shortkey\0actionAll_graphs_Shortkey\0"
    "on_chb_Distance_toggled\0distance_mouseRelease\0"
    "distance_mousePress\0distance_mouseMove"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      74,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  384,    2, 0x08 /* Private */,
       3,    0,  385,    2, 0x08 /* Private */,
       4,    0,  386,    2, 0x08 /* Private */,
       5,    1,  387,    2, 0x08 /* Private */,
       8,    0,  390,    2, 0x08 /* Private */,
       9,    0,  391,    2, 0x08 /* Private */,
      10,    0,  392,    2, 0x08 /* Private */,
      11,    1,  393,    2, 0x08 /* Private */,
      13,    0,  396,    2, 0x08 /* Private */,
      14,    1,  397,    2, 0x08 /* Private */,
      16,    0,  400,    2, 0x08 /* Private */,
      17,    0,  401,    2, 0x08 /* Private */,
      18,    0,  402,    2, 0x08 /* Private */,
      19,    1,  403,    2, 0x08 /* Private */,
      21,    1,  406,    2, 0x08 /* Private */,
      22,    1,  409,    2, 0x08 /* Private */,
      23,    1,  412,    2, 0x08 /* Private */,
      24,    1,  415,    2, 0x08 /* Private */,
      25,    1,  418,    2, 0x08 /* Private */,
      26,    1,  421,    2, 0x08 /* Private */,
      27,    1,  424,    2, 0x08 /* Private */,
      28,    1,  427,    2, 0x08 /* Private */,
      29,    1,  430,    2, 0x08 /* Private */,
      30,    1,  433,    2, 0x08 /* Private */,
      31,    1,  436,    2, 0x08 /* Private */,
      32,    1,  439,    2, 0x08 /* Private */,
      33,    1,  442,    2, 0x08 /* Private */,
      34,    1,  445,    2, 0x08 /* Private */,
      35,    1,  448,    2, 0x08 /* Private */,
      36,    1,  451,    2, 0x08 /* Private */,
      37,    0,  454,    2, 0x08 /* Private */,
      38,    0,  455,    2, 0x08 /* Private */,
      39,    0,  456,    2, 0x08 /* Private */,
      40,    0,  457,    2, 0x08 /* Private */,
      41,    0,  458,    2, 0x08 /* Private */,
      42,    0,  459,    2, 0x08 /* Private */,
      43,    1,  460,    2, 0x08 /* Private */,
      44,    1,  463,    2, 0x08 /* Private */,
      45,    0,  466,    2, 0x08 /* Private */,
      46,    0,  467,    2, 0x08 /* Private */,
      47,    1,  468,    2, 0x08 /* Private */,
      48,    1,  471,    2, 0x08 /* Private */,
      49,    1,  474,    2, 0x08 /* Private */,
      50,    0,  477,    2, 0x08 /* Private */,
      51,    1,  478,    2, 0x08 /* Private */,
      52,    1,  481,    2, 0x08 /* Private */,
      53,    1,  484,    2, 0x08 /* Private */,
      54,    1,  487,    2, 0x08 /* Private */,
      55,    1,  490,    2, 0x08 /* Private */,
      56,    1,  493,    2, 0x08 /* Private */,
      57,    0,  496,    2, 0x08 /* Private */,
      58,    1,  497,    2, 0x08 /* Private */,
      59,    1,  500,    2, 0x08 /* Private */,
      60,    0,  503,    2, 0x08 /* Private */,
      61,    1,  504,    2, 0x08 /* Private */,
      62,    1,  507,    2, 0x08 /* Private */,
      63,    1,  510,    2, 0x08 /* Private */,
      64,    1,  513,    2, 0x08 /* Private */,
      65,    1,  516,    2, 0x08 /* Private */,
      66,    1,  519,    2, 0x08 /* Private */,
      67,    1,  522,    2, 0x08 /* Private */,
      68,    1,  525,    2, 0x08 /* Private */,
      69,    1,  528,    2, 0x08 /* Private */,
      70,    1,  531,    2, 0x08 /* Private */,
      71,    1,  534,    2, 0x08 /* Private */,
      72,    1,  537,    2, 0x08 /* Private */,
      73,    0,  540,    2, 0x08 /* Private */,
      74,    0,  541,    2, 0x08 /* Private */,
      75,    0,  542,    2, 0x08 /* Private */,
      76,    0,  543,    2, 0x08 /* Private */,
      77,    1,  544,    2, 0x08 /* Private */,
      78,    1,  547,    2, 0x08 /* Private */,
      79,    1,  550,    2, 0x08 /* Private */,
      80,    1,  553,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_btn_add_clicked(); break;
        case 1: _t->on_btn_add2_clicked(); break;
        case 2: _t->on_btn_add3_clicked(); break;
        case 3: _t->xyGraph((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 4: _t->on_btn_Clean_xy_clicked(); break;
        case 5: _t->on_btn_Clean_xy2_clicked(); break;
        case 6: _t->on_btn_Clean_xy3_clicked(); break;
        case 7: _t->on_bx_Num_Node_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_btn_Fix_Graph_clicked(); break;
        case 9: _t->on_chb_Bound_Bandom_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->on_btn_Del_R_clicked(); break;
        case 11: _t->on_btn_Del_G_clicked(); break;
        case 12: _t->on_btn_Del_B_clicked(); break;
        case 13: _t->on_cbox_ScatterStyle_Red_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_cbox_ScatterStyle_Green_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_cbox_ScatterStyle_Blue_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_cbox_StyleLine_Red_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_cbox_StyleLine_Green_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->on_cbox_StyleLine_Blue_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->on_cbox_Size_Red_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_cbox_Size_Green_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->on_cbox_Size_Blue_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->on_chc_EnableMode_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 23: _t->on_actionRed_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->on_actionAll_graphs_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 25: _t->on_actionGreen_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->on_actionBlue_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: _t->on_actionEnable_selection_mode_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->on_actionFix_bound_or_randome_range_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 29: _t->graph_Menu((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 30: _t->on_actionFix_grapgs_triggered(); break;
        case 31: _t->on_actionRed_Cleen_triggered(); break;
        case 32: _t->actionGreen_Clean_triggered(); break;
        case 33: _t->on_actionBlue_Cleen_triggered(); break;
        case 34: _t->on_actionAll_Graphs_Clean_triggered(); break;
        case 35: _t->moveLegend(); break;
        case 36: _t->on_chb_ShowPointCoordinates_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 37: _t->on_actionEnable_show_point_coordinates_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 38: _t->on_actionStart_stop_triggered(); break;
        case 39: _t->on_btn_Start_Stop_toggled(); break;
        case 40: _t->on_rb_RightClick_Menu_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 41: _t->on_rb_RightClick_Editor_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 42: _t->Zoom_Drag((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 43: _t->rezoom(); break;
        case 44: _t->on_chb_Zone_Red_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 45: _t->on_chb_Zone_Green_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 46: _t->on_chb_Zone_Blue_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 47: _t->drag_mouseRelease((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 48: _t->drag_mouseMove((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 49: _t->drag_mousePress((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 50: _t->drag_plot(); break;
        case 51: _t->on_chb_ShowBund_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 52: _t->on_chb_Zone_All_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 53: _t->Zone_All_plot(); break;
        case 54: _t->on_bx_x_range1_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 55: _t->on_bx_x_range2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 56: _t->on_bx_y_range1_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 57: _t->on_bx_y_range2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 58: _t->on_bx_x2_range1_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 59: _t->on_bx_x2_range2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 60: _t->on_bx_y2_range1_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 61: _t->on_bx_y2_range2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 62: _t->on_bx_x3_range1_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 63: _t->on_bx_x3_range2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 64: _t->on_bx_y3_range1_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 65: _t->on_bx_y3_range2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 66: _t->actionRed_Shortkey(); break;
        case 67: _t->actionGreen_Shortkey(); break;
        case 68: _t->actionBlue_Shortkey(); break;
        case 69: _t->actionAll_graphs_Shortkey(); break;
        case 70: _t->on_chb_Distance_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 71: _t->distance_mouseRelease((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 72: _t->distance_mousePress((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 73: _t->distance_mouseMove((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 74)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 74;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 74)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 74;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
