/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *btn_deleteUser;
    QPushButton *btn_updateUsers;
    QGroupBox *groupBox;
    QPushButton *btn_addUser;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_2;
    QSpinBox *sb_age;
    QLabel *label_5;
    QLineEdit *le_lastName;
    QLabel *label_2;
    QLineEdit *le_firstName;
    QLabel *label;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout;
    QLineEdit *le_phone;
    QLabel *label_3;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_3;
    QLineEdit *le_address;
    QLabel *label_4;
    QPushButton *btn_userInformations;
    QTableView *tb_Users;
    QPushButton *btn_deleteAllUsers;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 624);
        MainWindow->setStyleSheet(QString::fromUtf8("    QWidget{font-size:14px;}\n"
"\n"
"     \n"
"\n"
"    QWidget#centralWidget{background:white;}\n"
"\n"
"     \n"
"\n"
"    QPushButton{\n"
"\n"
"    background:#03dac6;\n"
"\n"
"    color:white;\n"
"\n"
"    border:0px;\n"
"\n"
"    border-radius:10px;\n"
"\n"
"    min-height:20px;\n"
"\n"
"    min-width:30px;\n"
"\n"
"    padding:5px;\n"
"\n"
"    }\n"
"\n"
"     \n"
"\n"
"    QPushButton:hover{\n"
"\n"
"    background:#41cd52;\n"
"\n"
"    }\n"
"\n"
"     \n"
"\n"
"    QLineEdit{\n"
"\n"
"    border:1px solid gray;\n"
"\n"
"    border-radius:8px;\n"
"\n"
"    font-size:14px;\n"
"\n"
"    min-height:25px;\n"
"\n"
"    }\n"
"\n"
"     \n"
"\n"
"    QLineEdit:focus{\n"
"\n"
"    border:1px solid #03dac6;\n"
"\n"
"    border-radius:4px;\n"
"\n"
"    }\n"
"\n"
"     \n"
"\n"
"    QGroupBox{\n"
"\n"
"    background:lightgray;\n"
"\n"
"    border:0px;\n"
"\n"
"    font-weight:bold;\n"
"\n"
"    color:black;\n"
"\n"
"    border-radius:10px;\n"
"\n"
"    }\n"
"\n"
"     \n"
"\n"
"    QTableView{\n"
"\n"
"    borde"
                        "r:2px solid gray;\n"
"\n"
"    }"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        btn_deleteUser = new QPushButton(centralwidget);
        btn_deleteUser->setObjectName(QString::fromUtf8("btn_deleteUser"));
        btn_deleteUser->setGeometry(QRect(670, 500, 94, 36));
        btn_updateUsers = new QPushButton(centralwidget);
        btn_updateUsers->setObjectName(QString::fromUtf8("btn_updateUsers"));
        btn_updateUsers->setGeometry(QRect(40, 510, 171, 36));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(40, 10, 731, 181));
        btn_addUser = new QPushButton(groupBox);
        btn_addUser->setObjectName(QString::fromUtf8("btn_addUser"));
        btn_addUser->setGeometry(QRect(40, 129, 111, 31));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(51, 40, 661, 36));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        sb_age = new QSpinBox(layoutWidget);
        sb_age->setObjectName(QString::fromUtf8("sb_age"));

        horizontalLayout_2->addWidget(sb_age);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_2->addWidget(label_5);

        le_lastName = new QLineEdit(layoutWidget);
        le_lastName->setObjectName(QString::fromUtf8("le_lastName"));

        horizontalLayout_2->addWidget(le_lastName);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        le_firstName = new QLineEdit(layoutWidget);
        le_firstName->setObjectName(QString::fromUtf8("le_firstName"));

        horizontalLayout_2->addWidget(le_firstName);

        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_2->addWidget(label);

        layoutWidget1 = new QWidget(groupBox);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(520, 89, 191, 29));
        horizontalLayout = new QHBoxLayout(layoutWidget1);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        le_phone = new QLineEdit(layoutWidget1);
        le_phone->setObjectName(QString::fromUtf8("le_phone"));

        horizontalLayout->addWidget(le_phone);

        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout->addWidget(label_3);

        layoutWidget2 = new QWidget(groupBox);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(46, 89, 461, 29));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        le_address = new QLineEdit(layoutWidget2);
        le_address->setObjectName(QString::fromUtf8("le_address"));

        horizontalLayout_3->addWidget(le_address);

        label_4 = new QLabel(layoutWidget2);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_3->addWidget(label_4);

        btn_userInformations = new QPushButton(groupBox);
        btn_userInformations->setObjectName(QString::fromUtf8("btn_userInformations"));
        btn_userInformations->setGeometry(QRect(553, 130, 141, 36));
        tb_Users = new QTableView(centralwidget);
        tb_Users->setObjectName(QString::fromUtf8("tb_Users"));
        tb_Users->setGeometry(QRect(40, 210, 731, 271));
        btn_deleteAllUsers = new QPushButton(centralwidget);
        btn_deleteAllUsers->setObjectName(QString::fromUtf8("btn_deleteAllUsers"));
        btn_deleteAllUsers->setGeometry(QRect(500, 500, 131, 41));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 32));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
        QWidget::setTabOrder(le_firstName, le_lastName);
        QWidget::setTabOrder(le_lastName, sb_age);
        QWidget::setTabOrder(sb_age, le_phone);
        QWidget::setTabOrder(le_phone, le_address);
        QWidget::setTabOrder(le_address, btn_addUser);
        QWidget::setTabOrder(btn_addUser, btn_deleteUser);
        QWidget::setTabOrder(btn_deleteUser, btn_updateUsers);
        QWidget::setTabOrder(btn_updateUsers, tb_Users);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        btn_deleteUser->setText(QCoreApplication::translate("MainWindow", "\330\255\330\260\331\201 \332\251\330\247\330\261\330\250\330\261", nullptr));
        btn_updateUsers->setText(QCoreApplication::translate("MainWindow", "\330\253\330\250\330\252 \330\252\330\272\333\214\333\214\330\261\330\247\330\252", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "\331\205\330\264\330\256\330\265\330\247\330\252 \332\251\330\247\330\261\330\250\330\261", nullptr));
        btn_addUser->setText(QCoreApplication::translate("MainWindow", "\330\247\331\201\330\262\331\210\330\257\331\206 \332\251\330\247\330\261\330\250\330\261", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "\330\263\331\206", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\331\206\330\247\331\205 \330\256\331\204\330\247\331\206\331\210\330\247\330\257\332\257\333\214", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\331\206\330\247\331\205", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\330\252\331\204\331\201\331\206", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "\330\242\330\257\330\261\330\263", nullptr));
        btn_userInformations->setText(QCoreApplication::translate("MainWindow", "\331\201\330\261\331\205 \331\206\331\205\330\247\333\214\330\264 \332\251\330\247\330\261\330\250\330\261\330\247\331\206", nullptr));
        btn_deleteAllUsers->setText(QCoreApplication::translate("MainWindow", "\330\255\330\260\331\201 \331\207\331\205\331\207 \332\251\330\247\330\261\330\250\330\261\330\247\331\206", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
