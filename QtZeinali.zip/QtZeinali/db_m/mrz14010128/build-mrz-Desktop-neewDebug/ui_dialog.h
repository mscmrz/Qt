/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLabel *lb_FName;
    QLabel *label;
    QLabel *lb_LName;
    QLabel *label_3;
    QSpinBox *spinBox;
    QWidget *layoutWidget_2;
    QGridLayout *gridLayout_4;
    QLabel *lb_phone;
    QLabel *label_5;
    QLabel *lb_age;
    QLabel *label_6;
    QLabel *lb_Address;
    QLabel *label_9;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout;
    QLabel *lbb;
    QLabel *label_2;
    QLabel *lb_bbbb;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(566, 246);
        layoutWidget = new QWidget(Dialog);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(270, 72, 261, 62));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        lb_FName = new QLabel(layoutWidget);
        lb_FName->setObjectName(QString::fromUtf8("lb_FName"));

        gridLayout->addWidget(lb_FName, 0, 0, 1, 1);

        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 1, 1, 1);

        lb_LName = new QLabel(layoutWidget);
        lb_LName->setObjectName(QString::fromUtf8("lb_LName"));

        gridLayout->addWidget(lb_LName, 1, 0, 1, 1);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 1, 1, 1, 1);

        spinBox = new QSpinBox(Dialog);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(340, 20, 54, 34));
        spinBox->setMinimum(0);
        layoutWidget_2 = new QWidget(Dialog);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(10, 82, 231, 62));
        gridLayout_4 = new QGridLayout(layoutWidget_2);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        lb_phone = new QLabel(layoutWidget_2);
        lb_phone->setObjectName(QString::fromUtf8("lb_phone"));

        gridLayout_4->addWidget(lb_phone, 0, 0, 1, 1);

        label_5 = new QLabel(layoutWidget_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_4->addWidget(label_5, 0, 1, 1, 1);

        lb_age = new QLabel(layoutWidget_2);
        lb_age->setObjectName(QString::fromUtf8("lb_age"));

        gridLayout_4->addWidget(lb_age, 1, 0, 1, 1);

        label_6 = new QLabel(layoutWidget_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_4->addWidget(label_6, 1, 1, 1, 1);

        lb_Address = new QLabel(Dialog);
        lb_Address->setObjectName(QString::fromUtf8("lb_Address"));
        lb_Address->setGeometry(QRect(12, 150, 311, 20));
        label_9 = new QLabel(Dialog);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(350, 150, 181, 20));
        layoutWidget1 = new QWidget(Dialog);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(380, 210, 151, 29));
        horizontalLayout = new QHBoxLayout(layoutWidget1);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        lbb = new QLabel(layoutWidget1);
        lbb->setObjectName(QString::fromUtf8("lbb"));

        horizontalLayout->addWidget(lbb);

        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        lb_bbbb = new QLabel(Dialog);
        lb_bbbb->setObjectName(QString::fromUtf8("lb_bbbb"));
        lb_bbbb->setGeometry(QRect(120, 200, 63, 20));

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        lb_FName->setText(QString());
        label->setText(QCoreApplication::translate("Dialog", "\331\206\330\247\331\205", nullptr));
        lb_LName->setText(QString());
        label_3->setText(QCoreApplication::translate("Dialog", "\331\206\330\247\331\205 \330\256\330\247\331\206\331\210\330\247\330\257\332\257\333\214", nullptr));
        lb_phone->setText(QString());
        label_5->setText(QCoreApplication::translate("Dialog", "\330\252\331\204\331\201\331\206", nullptr));
        lb_age->setText(QString());
        label_6->setText(QCoreApplication::translate("Dialog", "\330\263\331\206", nullptr));
        lb_Address->setText(QString());
        label_9->setText(QCoreApplication::translate("Dialog", "\330\242\330\257\330\261\330\263", nullptr));
        lbb->setText(QString());
        label_2->setText(QCoreApplication::translate("Dialog", "\330\252\330\271\330\257\330\247\330\257 \332\251\330\247\330\261\330\250\330\261\330\247\331\206:", nullptr));
        lb_bbbb->setText(QCoreApplication::translate("Dialog", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
