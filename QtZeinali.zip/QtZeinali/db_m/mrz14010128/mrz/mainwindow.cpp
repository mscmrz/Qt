#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "form.h"
#include <QDebug>
#include <QTableWidget>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent):
  QMainWindow(parent)
  , ui(new Ui::MainWindow)
{
  ui->setupUi(this);
  setWindowTitle("User profile");
  MyDialog = new Dialog;

  connect(this, SIGNAL(sendIntData(int,int)), MyDialog, SLOT(setIntData(int,int)));
  ui->le_firstName->setFocus();

  ui->le_phone->setValidator(new QRegExpValidator(QRegExp("[0-9]{11}")));

  if (createConnection())
  {
    qDebug() << "connect ok;";
    m_qu = new QSqlQuery(m_db);
    createTable();

    m_tbModel = new QSqlTableModel(this, m_db);
    m_tbModel->setTable("Users");
    m_tbModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    m_tbModel->select();

    ui->tb_Users->setModel(m_tbModel);
    ui->tb_Users->setColumnHidden(0, true);
    ui->tb_Users->setColumnWidth(0, 20);
    ui->tb_Users->setColumnWidth(1, 100);
    ui->tb_Users->setColumnWidth(2, 100);
    ui->tb_Users->setColumnWidth(3, 20);
    ui->tb_Users->setColumnWidth(4, 100);
    ui->tb_Users->setColumnWidth(5, 180);
  }
  else
  {
    qDebug() << "Error: caon't open database";
    exit(0);
  }
}

MainWindow::~MainWindow()
{
  delete m_tbModel;

  if (m_db.isOpen())
  {
    m_db.close();
  }

  delete m_qu;

  delete ui;
}

bool  MainWindow::createConnection()
{
  m_db = QSqlDatabase::addDatabase("QSQLITE");
  m_db.setDatabaseName("mydb.db");

  if (!m_db.open())
  {
    qDebug() << "An error on opening database : " << m_db.lastError();

    return false;
  }

  return true;
}

void  MainWindow::createTable()
{
  if (!m_db.isOpen())
  {
    return;
  }

  if (!m_qu->exec("CREATE TABLE IF NOT EXISTS Users"

                  "(id integer PRIMARY KEY AUTOINCREMENT,"

                  "fname varchar(32),lname varchar(32),age int,"

                  "phone varchar(12),address varchar(128) );"))
  {
    qDebug() << "createTable:error :" << m_qu->lastError();
  }
}

bool  MainWindow::addUser(QString fname, QString lname, int age, QString phone, QString address)
{
  if (!m_qu->exec("insert into Users(fname,lname,age,phone,address) "

                  "values('" + fname + "', '" + lname + "', " + QString::number(age) + ", '" + phone + "', '" + address + "')"))
  {
    qDebug() << "userAdded:error :" << m_qu->lastError();

    return false;
  }

  return true;
}

bool  MainWindow::deleteUser(int id)
{
  if (!m_qu->exec("DELETE FROM Users "

                  "WHERE id = " + QString::number(id) + ";"))
  {
    qDebug() << "deleteUser: error:" << m_qu->lastError();

    return false;
  }

  return true;
}

bool  MainWindow::updateUser(int id, QString fname, QString lname, int age, QString phone, QString address)
{
  if (!m_qu->exec("update Users "

                  "set fname= '" + fname + "', lname ='" + lname + "', age=" + QString::number(age) + ", phone='" + phone + "'" + ", address='" + address + "' "

                                                                                                                                                            "where id=" + QString::number(id)))
  {
    qDebug() << "updateUser: error :" << m_qu->lastError();

    return false;
  }

  return true;
}

void  MainWindow::on_btn_addUser_clicked()
{
  if (ui->le_firstName->text().isEmpty() || ui->le_lastName->text().isEmpty())
  {
    QMessageBox::warning(this, "خطا", "پر کردن فیلدهای نام و نام خانوادگی الزامی است. ");

    return;
  }

  if (addUser(ui->le_firstName->text(),

              ui->le_lastName->text(),

              ui->sb_age->value(),

              ui->le_phone->text(),

              ui->le_address->text()))
  {
    qDebug() << "added!";

    m_tbModel->select();

    ui->tb_Users->selectRow(m_tbModel->rowCount() - 1);

    clearForm();
  }

  ui->le_firstName->setFocus();
}

void  MainWindow::clearForm()
{
  ui->le_firstName->clear();
  ui->le_lastName->clear();
  ui->sb_age->setValue(0);
  ui->le_phone->clear();
  ui->le_address->clear();
}

void  MainWindow::on_btn_updateUsers_clicked()
{
  QMessageBox::StandardButton  answer_update = QMessageBox::question(this, "ثبت تغییرات", " آیا می خوهید تغییرات ثبت شود ");

  if (answer_update == QMessageBox::Yes)
  {
    m_tbModel->submitAll();
    qDebug() << " successfully.";
  }
  else
  {
    qDebug() << " Error.";
  }
}

void  MainWindow::on_btn_deleteUser_clicked()
{
  id_current = m_tbModel->index(ui->tb_Users->currentIndex().row(), 0).data().toInt();
  int                          row    = ui->tb_Users->verticalHeader()->currentIndex().row() + 1;
  QMessageBox::StandardButton  answer = QMessageBox::question(this, "هشدار",

                                                              "  آیا میخواهید مشخصات کاربر شماره: " + QString::number(row) + " را حذف کنید؟  ");

  if (answer == QMessageBox::Yes)
  {
    if (deleteUser(id_current))
    {
      m_tbModel->select();
      qDebug() << "remove id: " << row << " successfully.";
    }
  }
}

void  MainWindow::on_btn_deleteAllUsers_clicked()
{
  id_count = ui->tb_Users->model()->rowCount();
  QMessageBox::StandardButton  answer = QMessageBox::question(this, "هشدار",

                                                              "  آیا میخواهید تمامی کاربران (" + QString::number(id_count) + ") را حذف کنید؟ ");

  if (answer == QMessageBox::Yes)
  {
    if (!m_qu->exec("DELETE FROM Users "))
    {
      m_tbModel->select();
      m_tbModel->submitAll();
      qDebug() << "remove all users with successfully.";
    }

    m_tbModel->submitAll();
    m_qu->prepare("UPDATE Users");
  }
}

void  MainWindow::on_btn_userInformations_clicked()
{
  int   row = ui->tb_Users->verticalHeader()->currentIndex().row() + 1;
  emit  sendIntData(ui->tb_Users->model()->rowCount(), row);

  MyDialog->children();
  MyDialog->exec();
}
