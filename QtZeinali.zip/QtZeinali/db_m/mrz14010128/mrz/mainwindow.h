#ifndef MAINWINDOW_H
#define MAINWINDOW_H


#include "dialog.h"
#include <QMainWindow>
#include <QtSql/QSql>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlTableModel>
\
  QT_BEGIN_NAMESPACE
namespace Ui
{
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow: public QMainWindow
{
  Q_OBJECT

public:
  MainWindow(QWidget *parent = nullptr);

  ~MainWindow();

signals:
  void  sendIntData(int row_max, int row_current);

public slots:
  bool  createConnection();

  void  createTable();

  bool  addUser(QString fname, QString lname, int age, QString phone, QString address);

  bool  deleteUser(int id);

  bool  updateUser(int id, QString fname, QString lname, int age, QString phone, QString address);

private slots:
  void  on_btn_addUser_clicked();

  void  clearForm();

  void  on_btn_updateUsers_clicked();

  void  on_btn_deleteUser_clicked();

  void  on_btn_deleteAllUsers_clicked();

  void  on_btn_userInformations_clicked();

private:
  Ui::MainWindow *ui;
  QSqlDatabase    m_db;
  QSqlQuery      *m_qu;
  QSqlTableModel *m_tbModel;
  int             id_current = 0;
  Dialog         *MyDialog;
  int             id_count = 0;

public:
};
#endif // MAINWINDOW_H
