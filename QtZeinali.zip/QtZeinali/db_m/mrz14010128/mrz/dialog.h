#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QtSql/QSqlTableModel>
#include <QtSql/QSqlRecord>
#include <QtSql>

namespace Ui
{
class Dialog;
}

class Dialog: public QDialog
{
  Q_OBJECT

public:
  explicit Dialog(QWidget *parent = nullptr);

  ~Dialog();

private:
  Ui::Dialog *ui;
  int         idd = 0;

public slots:
  void  getIdInfo(int id);

  void  setIntData(int max_row, int current_row);

private slots:
  void  on_spinBox_valueChanged(int arg1);
};

#endif // DIALOG_H
