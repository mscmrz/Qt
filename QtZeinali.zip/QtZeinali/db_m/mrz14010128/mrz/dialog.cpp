#include "dialog.h"
#include "ui_dialog.h"
#include <QString>

Dialog::Dialog(QWidget *parent):
  QDialog(parent),
  ui(new Ui::Dialog)
{
  ui->setupUi(this);

// connect(ui->spinBox, SIGNAL(valueChanged(int)), this, SLOT(getIdInfo(int)));

  connect(ui->spinBox, SIGNAL(valueChanged(int)), this, SLOT(on_spinBox_valueChanged(int arg1)));
}

Dialog::~Dialog()
{
  delete ui;
}

// void  Dialog::getIdInfo(int id)
// {
// QSqlTableModel  tb;

// id = ui->spinBox->value();

// ui->lbb->setText(QString::number(id));

// tb.setTable("Users");

// tb.setFilter("id=" + QString::number(id));

// tb.select();

// ui->lb_FName->setText(tb.record(0).value("fname").toString());

// ui->lb_LName->setText(tb.record(0).value("lname").toString());

// ui->lb_phone->setText(tb.record(0).value("phone").toString());

// ui->lb_age->setText(tb.record(0).value("age").toString());

// ui->lb_Address->setText(tb.record(0).value("address").toString());
// }

void  Dialog::setIntData(int max_r, int current_r)
{
  ui->spinBox->setValue(current_r);
// ui->spinBox->setMaximum(max_r);
  ui->lbb->setText(QString::number(max_r));
}

void  Dialog::on_spinBox_valueChanged(int arg1)
{
  QSqlTableModel  tb;

  ui->lb_bbbb->setText(QString::number(arg1));

  tb.setTable("Users");

  tb.setFilter("id=" + QString::number(arg1));

  tb.select();

  ui->lb_FName->setText(tb.record(0).value("fname").toString());

  ui->lb_LName->setText(tb.record(0).value("lname").toString());

  ui->lb_phone->setText(tb.record(0).value("phone").toString());

  ui->lb_age->setText(tb.record(0).value("age").toString());

  ui->lb_Address->setText(tb.record(0).value("address").toString());
}
