#ifndef USERSINFOFORM_H
#define USERSINFOFORM_H

#include <QWidget>
#include <QtSql/QSqlTableModel>
#include <QtSql/QSqlRecord>
#include "mainwindow.h"
#include <QtSql>

namespace Ui
{
class usersInfo;
}

class usersInfo: public QWidget
{
  Q_OBJECT

public:
  explicit usersInfo(QWidget *parent = nullptr);

  ~usersInfo();

private:
  Ui::usersInfo *ui;

public slots:
  void  getIdInfo(int id);

private slots:
};

#endif // USERSINFOFORM_H
