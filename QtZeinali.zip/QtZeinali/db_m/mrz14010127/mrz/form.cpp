#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent):
  QWidget(parent),
  ui(new Ui::Form)
{
  ui->setupUi(this);
  connect(ui->spinBox, SIGNAL(valueChanged(int)), this, SLOT(getIdInfo(int)));
}

Form::~Form()
{
  delete ui;
}

void  Form::getIdInfo(int id)
{
  QSqlTableModel  tb;

  tb.setTable("Users");

  tb.setFilter("id=" + QString::number(id));

  tb.select();

  ui->lb_FName->setText(tb.record(0).value("fname").toString());

  ui->lb_LName->setText(tb.record(0).value("lname").toString());

  ui->lb_phone->setText(tb.record(0).value("phone").toString());

  ui->lb_age->setText(tb.record(0).value("age").toString());

  ui->lb_Address->setText(tb.record(0).value("address").toString());
}
