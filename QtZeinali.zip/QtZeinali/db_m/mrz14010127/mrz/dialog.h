#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QtSql/QSqlTableModel>
#include <QtSql/QSqlRecord>
#include <QtSql>

namespace Ui
{
class Dialog;
}

class Dialog: public QDialog
{
  Q_OBJECT

public:
  explicit Dialog(QWidget *parent = nullptr);

  ~Dialog();

private:
  Ui::Dialog *ui;

public slots:
  void  getIdInfo(int id);

  int  id_cc;

  void  setIntData(int max_row, int current_row);
};

#endif // DIALOG_H
