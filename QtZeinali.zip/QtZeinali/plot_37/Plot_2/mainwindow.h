#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QRandomGenerator>
#include <QTimer>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit  MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void addPoint(double x , double y);
    void addPoint2(double x , double y);
    void addPoint3(double x , double y);
    void addPoint4(double x , double y);

    void removePoint(double x, double y);
    void removePoint2(double x, double y);
    void removePoint3(double x, double y);


    void bound_Auto();
    void bound_range();


    void plot();
    void plot2();
    void plot3();
    void plot4();
    void plot4_Selected();

    void autoAddPoint();

    void cleardata();

    void clean_Selected_Graph();

    void check_Allgrapg();

    void on_actionFix_graphs_triggered();

private slots:



    void on_btn_add_clicked();
    void on_btn_add2_clicked();
    void on_btn_add3_clicked();



    void xyGraph(QMouseEvent *event);



    void on_btn_Clean_xy_clicked();
    void on_btn_Clean_xy2_clicked();
    void on_btn_Clean_xy3_clicked();

    void on_btn_clear_clicked();

    void on_bx_Num_Node_valueChanged(int arg1);

    void on_btn_Fix_Graph_clicked();

    void on_chb_Bound_Bandom_toggled(bool checked);

    void on_btn_Del_R_clicked();

    void on_btn_Del_G_clicked();

    void on_btn_Del_B_clicked();

    void on_cbox_ScatterStyle_Red_currentIndexChanged(int index);

    void on_cbox_ScatterStyle_Green_currentIndexChanged(int index);

    void on_cbox_ScatterStyle_Blue_currentIndexChanged(int index);

    void on_cbox_StyleLine_Red_currentIndexChanged(int index);

    void on_cbox_StyleLine_Green_currentIndexChanged(int index);

    void on_cbox_StyleLine_Blue_currentIndexChanged(int index);

    void on_cbox_Size_Red_valueChanged(int arg1);

    void on_cbox_Size_Green_valueChanged(int arg1);

    void on_cbox_Size_Blue_valueChanged(int arg1);

    void on_chc_EnableMode_toggled(bool checked);

    void on_actionRed_triggered(bool checked);

    void on_actionAll_graphs_triggered(bool checked);

    void on_actionGreen_triggered(bool checked);

    void on_actionBlue_triggered(bool checked);

    void on_actionEnable_selection_mode_triggered(bool checked);

    void on_actionFix_bound_or_randome_range_triggered(bool checked);



    void graph_Menu(QMouseEvent *event);

    void on_actionFix_grapgs_triggered();

    void on_actionRed_Cleen_triggered();

    void on_actionGreen_Cean_triggered();

    void on_actionBlue_Cleen_triggered();

    void on_actionAll_Graphs_Clean_triggered();

    void moveLegend();

    void on_chb_ShowPointCoordinates_toggled(bool checked );

    void on_actionEnable_show_point_coordinates_triggered(bool checked);

    void on_actionStart_stop_triggered();

    void on_btn_Start_Stop_toggled();

    void on_rb_RightClick_Menu_toggled(bool checked);

    void on_rb_RightClick_Editor_toggled(bool checked);

    void Zoom_Drag(QMouseEvent *event);

    void  rezoom();


    void on_chb_Zone_Red_toggled(bool checked);

    void on_chb_Zone_Green_toggled(bool checked);

    void on_chb_Zone_Blue_toggled(bool checked);

    void drag_mouseRelease(QMouseEvent *event);

    void drag_mouseMove(QMouseEvent *event);

    void drag_mousePress(QMouseEvent *event);

    void drag_plot();



    void on_chb_ShowBund_toggled(bool checked);



public slots:


private:
    Ui::MainWindow *ui;

    int count_Node_Grapgh=0,UpdateTime=0,num=0, auto_manually=0 ;

    int xRange1=0,xRange2=0,x2Range1=0,x2Range2=0,x3Range1=0,x3Range2=0;
    int yRange1=0,yRange2=0,y2Range1=0,y2Range2=0,y3Range1=0,y3Range2=0;

    int max_X2_graphs=0,max_Y2_graphs=0;

    int color_scautter;

    QVector<double> gv_x, gv_y,gv_x2, gv_y2,gv_x3, gv_y3,gv_x4, gv_y4;

    QRandomGenerator64 rd;
    QTimer *time=nullptr;
    bool start_Stop,chb_auto,chb_ShowPoint;

    QPoint p_Mouse_Press,p_Mouse_Move,p_Mouse_Release;

    double x_mousePress,y_mousePress,x_mouseRelease,y_mouseRelease, x_mouseMove,y_mouseMove;




    // QWidget interface
    protected:

        protected slots:

};
#endif // MAINWINDOW_H
