#ifndef MYSERVICE_H
#define MYSERVICE_H

#include <QObject>
#include <proc_service.h>


class MyService : public serv
{
  Q_OBJECT
public:
  explicit MyService(QObject *parent = nullptr);

signals:

};

#endif // MYSERVICE_H
