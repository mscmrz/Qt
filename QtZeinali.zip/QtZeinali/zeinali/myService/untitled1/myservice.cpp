#include "myservice.h"

MyService::MyService(QObject *parent) : QObject(parent)
{

}
