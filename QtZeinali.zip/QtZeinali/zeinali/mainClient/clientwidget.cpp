#include "clientwidget.h"
#include "ui_clientwidget.h"
#include <QDate>
#include <QHostAddress>
#include <QMessageBox>
#include <QTextStream>
#include <QDesktopServices>

clientwidget::clientwidget(QWidget *parent):
  QWidget(parent)
  , ui(new Ui::clientwidget)
{
  ui->setupUi(this);
  setWindowTitle("Client");

  ui->lineEditIP->setFocus();
  ui->Send->setEnabled(false);

  tcpSocket = nullptr;
  tcpSocket = new QTcpSocket(this);


  QLocale  loc(QLocale::English, QLocale::UnitedKingdom);

  QLocale::setDefault(loc);

  date = QDate::currentDate();
  time = QTime::currentTime();

  strDate = date.toString("hh:mm:ss");
  strTime = time.toString("yyyy/MM/dd");

  timeEn = loc.toString(time, "hh:mm:ss");
  dateEn = loc.toString(date, "yyyy/MM/dd");

  QString  strDateTime = dateEn + "  " + timeEn;

  connect(tcpSocket, &QTcpSocket::disconnected, [ = ]()
  {
    // ui->Send->setEnabled(false);
  }
          );

  connect(tcpSocket, &QTcpSocket::connected, [ = ]()
  {
    ui->textEditRead->setText("Successfully established a connection with th server [ " + strDateTime + " ]");
    ui->lineEditIP->setEnabled(false);
    ui->lineEditPort->setEnabled(true);
    ui->Connect->setEnabled(false);
    ui->Send->setEnabled(true);
  }
          );
  connect(tcpSocket, &QTcpSocket::readyRead, [ = ]()
  {
    QByteArray array = tcpSocket->readAll();
    ui->textEditRead->append(array);
  }
          );
}

clientwidget::~clientwidget()
{
  delete ui;
}

void          clientwidget::on_Connect_clicked()
{
  QString  ip   = ui->lineEditIP->text();
  qint16   port = ui->lineEditPort->text().toInt();

  tcpSocket->connectToHost(QHostAddress(ip), port);
}

void          clientwidget::on_Send_clicked()
{
  ui->textEditRead->moveCursor(QTextCursor::End);
  QString  strText = ui->textEditWrite->toPlainText();

  if (strText != NULL)
  {
    QString  str = QString("[Client : %1 ] %2 ").arg(timeEn).arg(strText);
    tcpSocket->write(str.toUtf8().data());

    ui->textEditRead->append(str);
    ui->textEditWrite->clear();
  }

  ui->textEditWrite->setFocus();
}

void          clientwidget::on_Close_clicked()
{
  QString  str = "User is disconnected " + timeEn;

  tcpSocket->write(str.toUtf8().data());
  tcpSocket->disconnectFromHost();
  tcpSocket->close();

  ui->lineEditIP->setEnabled(true);
  ui->lineEditPort->setEnabled(true);

  ui->Connect->setEnabled(true);
  ui->Send->setEnabled(false);
}

void          clientwidget::on_btn_BackupData_clicked()
{
  QLocale  loc(QLocale::English, QLocale::UnitedKingdom);

  QLocale::setDefault(loc);

  // QLocale  loc(QLocale::Persian, QLocale::Iran);
  // QLocale::setDefault(loc);

  date = QDate::currentDate();
  time = QTime::currentTime();

  timeEn = loc.toString(time, "hhmmss");
  dateEn = loc.toString(date, "yyyyMMdd");

  QPixmap  pixmapOk(":/gif/src/gif/ok.jpg");
  QPixmap  pixmaCancel(":/gif/src/gif/cancel.png");
  QPixmap  pixmaWriting(":/gif/src/gif/writing.png)");

  strFileName = "/home/siahi/Downloads/zeinali/mainClient/Backup/Client" + dateEn + "-" + timeEn + ".txt";
  QFile *file = new QFile(strFileName);

  if (ui->textEditRead->toPlainText() != NULL)
  {
    int  ret = QMessageBox::question(this, tr("Backup File"),
                                     tr("The document has been modified.\n"
                                        "Do you want to save your changes?"),
                                     QMessageBox::Save | QMessageBox::Cancel,
                                     QMessageBox::Save);

    switch (ret)
    {
    case QMessageBox::Save:
    {
      file->open(QIODevice::WriteOnly | QIODevice::Text);
      QTextStream  out(file);
      out << ui->textEditRead->toPlainText();
      file->close();

      ui->lbl_backup_Status->setPixmap(pixmapOk);
      ui->lbl_path->setText("Path file: " + strFileName);

      break;
    }
    case QMessageBox::Cancel:
    {
      ui->lbl_backup_Status->setPixmap(pixmaCancel);
      ui->lbl_path->setText("");
      break;
    }
    }
  }
}

void          clientwidget::on_textEditWrite_textChanged()
{
  QPixmap  pixmaWriting(":/gif/src/gif/writing.png)");

  ui->lbl_backup_Status->setPixmap(pixmaWriting);
  ui->lbl_path->setText("");
}

void          clientwidget::on_pushButton_clicked()
{
// QString  fileName = ui->lbl_path->text();

  // QFile    file(fileName);
  // if(file.open(QIODevice::ReadWrite))
  // {
  // QTextStream text(&file);
  // }
  QDesktopServices::openUrl(QUrl(strFileName));
}
