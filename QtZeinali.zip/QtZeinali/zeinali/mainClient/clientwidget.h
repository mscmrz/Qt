#ifndef CLIENTWIDGET_H
#define CLIENTWIDGET_H

#include <QWidget>
#include <QTcpSocket>
#include <QDate>
#include <QTime>
#include <QFile>


QT_BEGIN_NAMESPACE
namespace Ui
{
class clientwidget;
}
QT_END_NAMESPACE

class clientwidget: public QWidget
{
  Q_OBJECT

public:
  clientwidget(QWidget *parent = nullptr);

  ~clientwidget();

private slots:
  void          on_Connect_clicked();

  void          on_Send_clicked();

  void          on_Close_clicked();

  void          on_btn_BackupData_clicked();

  void          on_textEditWrite_textChanged();

  void          on_pushButton_clicked();

private:
  Ui::clientwidget *ui;
  QTcpSocket       *tcpSocket;
  QString           strDate;
  QString           strTime;
  QString           timeEn;
  QString           dateEn;
  QDate             date;
  QTime             time;
// QFile            *file;
  QString  strFileName;
};
#endif // CLIENTWIDGET_H
