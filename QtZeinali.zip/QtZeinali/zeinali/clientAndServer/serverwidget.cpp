#include "serverwidget.h"
#include "ui_serverwidget.h"
#include <QLocale>
#include <QMessageBox>
#include <QTextStream>

serverwidget::serverwidget(QWidget *parent):
  QWidget(parent)
  , ui(new Ui::serverwidget)
{
  ui->setupUi(this);

  setWindowTitle("The server :9999");

  ui->textEditWrite->setFocus();
  dis = false;

  tcpServer = nullptr;
  tcpSocket = nullptr;

  QLocale  loc(QLocale::English, QLocale::UnitedKingdom);

  QLocale::setDefault(loc);

  date = QDate::currentDate();
  time = QTime::currentTime();

  strDate = date.toString("hh:mm:ss");
  strTime = time.toString("yyyy/MM/dd");

  timeEn = loc.toString(time, "hh:mm:ss");
  dateEn = loc.toString(date, "yyyy/MM/dd");

  QString  strDateTime = dateEn + "  " + timeEn;

  tcpServer = new QTcpServer(this);
  tcpServer->listen(QHostAddress::Any, 9999);


  connect(tcpServer, &QTcpServer::newConnection, [ = ]()
  {
    tcpSocket = tcpServer->nextPendingConnection();

    QString ip   = tcpSocket->peerAddress().toString();
    quint16 port = tcpSocket->peerPort();

    QString temp = "Successfully connected [" + ip + "-" + QString::number(port) + "]";
    ui->textEditRead->setText(temp);

    connect(tcpSocket, &QTcpSocket::readyRead, [ = ]()
    {
      QByteArray array = tcpSocket->readAll();
      ui->textEditRead->append(array);
    }
            );
  }
          );
}

serverwidget::~serverwidget()
{
  delete ui;
}

void          serverwidget::on_Send_clicked()
{
  if (nullptr == tcpSocket)
  {
    return;
  }

  ui->textEditRead->moveCursor(QTextCursor::End);
  QString  strText = ui->textEditWrite->toPlainText();

  if (strText != NULL)
  {
    QString  str = QString("[Server : %1 ] %2 ").arg(timeEn).arg(strText);
    tcpSocket->write(str.toUtf8().data());

    ui->textEditRead->append(str);
    ui->textEditWrite->clear();
  }

  ui->textEditWrite->setFocus();
}

void          serverwidget::on_pushButton_clicked()
{
  if (nullptr == tcpSocket)
  {
    return;
  }

  QString  str = "server is disconnected " + timeEn;

  tcpSocket->write(str.toUtf8().data());

  tcpSocket->disconnectFromHost();
  tcpSocket->close();
  tcpSocket = nullptr;
  dis       = true;
}

void          serverwidget::on_btn_Connect_clicked()
{
  if (dis) { tcpServer->listen(QHostAddress::LocalHost, 9999); }
}

void          serverwidget::on_btn_BackupData_clicked()
{
  QLocale  loc(QLocale::English, QLocale::UnitedKingdom);

  QLocale::setDefault(loc);

  date = QDate::currentDate();
  time = QTime::currentTime();

  timeEn = loc.toString(time, "hhmmss");
  dateEn = loc.toString(date, "yyyyMMdd");

  QPixmap  pixmapOk(":/gif/src/gif/ok.jpg");
  QPixmap  pixmaCancel(":/gif/src/gif/cancel.png");
  QPixmap  pixmaWriting(":/gif/src/gif/writing.png)");
  QString  strFileName = "/home/siahi/Downloads/zeinali/clientAndServer/Backup/" + dateEn + "-" + timeEn + ".txt";

  file = new QFile(strFileName);

  if (ui->textEditRead->toPlainText() != NULL)
  {
    int  ret = QMessageBox::question(this, tr("Backup File"),
                                     tr("The document has been modified.\n"
                                        "Do you want to save your changes?"),
                                     QMessageBox::Save | QMessageBox::Cancel,
                                     QMessageBox::Save);

    switch (ret)
    {
    case QMessageBox::Save:
    {
      file->open(QIODevice::WriteOnly | QIODevice::Text);
      QTextStream  out(file);
      out << ui->textEditRead->toPlainText();
      file->close();

      ui->lbl_backup_status->setPixmap(pixmapOk);
      ui->lbl_path->setText("Path file: " + strFileName);

      break;
    }
    case QMessageBox::Cancel:
    {
      ui->lbl_backup_status->setPixmap(pixmaCancel);
      ui->lbl_path->setText("");
      break;
    }
    }
  }
}

void          serverwidget::on_textEditWrite_textChanged()
{
  QPixmap  pixmaWriting(":/gif/src/gif/writing.png)");

  ui->lbl_backup_status->setPixmap(pixmaWriting);
  ui->lbl_path->setText("");
}
