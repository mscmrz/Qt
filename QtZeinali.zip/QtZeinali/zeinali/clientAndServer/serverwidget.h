#ifndef SERVERWIDGET_H
#define SERVERWIDGET_H

#include <QWidget>
#include <QTcpSocket>
#include <QTcpServer>
#include <QFile>
#include <QDateTime>


QT_BEGIN_NAMESPACE
namespace Ui
{
class serverwidget;
}
QT_END_NAMESPACE

class serverwidget: public QWidget
{
  Q_OBJECT

public:
  serverwidget(QWidget *parent = nullptr);

  ~serverwidget();

private slots:
  void          on_Send_clicked();

  void          on_pushButton_clicked();

  void          on_btn_Connect_clicked();

  void          on_btn_BackupData_clicked();

  void          on_textEditWrite_textChanged();

private:
  Ui::serverwidget *ui;
  QTcpServer       *tcpServer;
  QTcpSocket       *tcpSocket;
  bool              dis; // Disconnect true or false
  QString           strDate;
  QString           strTime;
  QString           timeEn;
  QString           dateEn;
  QDate             date;
  QTime             time;
  QFile            *file;
};
#endif // SERVERWIDGET_H
