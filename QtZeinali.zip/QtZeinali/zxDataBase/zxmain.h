#ifndef ZXMAIN_H
#define ZXMAIN_H

#include <QMainWindow>
#include <QtSql>
#include <mydialog.h>

namespace Ui
{
class zxMain;
}

class zxMain: public QMainWindow
{
  Q_OBJECT

public:
  explicit zxMain(QWidget *parent = 0);

  ~zxMain();

  bool  createConnection();

  void  createTable();

  bool  addUser(QString fname, QString lname, int age, QString phone, QString address);

  bool  updateUser(int id, QString fname, QString lname, int age, QString phone, QString address);

  bool  deleteUser(int id);

  void  clearForm();

private:
  Ui::zxMain     *ui;
  QSqlDatabase    m_db;
  QSqlQuery      *m_qu;
  QSqlTableModel *m_tbModel;
  myDialog       *mmDial;

private slots:
  void  btn_addUser();

  void  btn_updateUsers();

  void  btn_deleteUser();

  void  on_pushButton_clicked();
};

#endif // ZXMAIN_H
