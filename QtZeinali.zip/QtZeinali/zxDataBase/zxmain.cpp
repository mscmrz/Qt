#include "zxmain.h"
#include "ui_zxmain.h"
#include <QDebug>
#include <QMessageBox>
// #include <QSqlError>

zxMain::zxMain(QWidget *parent):
  QMainWindow(parent),
  ui(new Ui::zxMain)
{
  ui->setupUi(this);
  mmDial = new myDialog;

  if (createConnection())
  {
    qDebug() << "connect ok;";
    m_qu = new QSqlQuery(m_db);
    createTable();
    m_tbModel = new QSqlTableModel(this, m_db);
    m_tbModel->setTable("Users");
    m_tbModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    m_tbModel->select();
    ui->tb_Users->setModel(m_tbModel);
    ui->tb_Users->setColumnWidth(0, 20);
    ui->tb_Users->setColumnWidth(1, 100);
    ui->tb_Users->setColumnWidth(2, 100);
    ui->tb_Users->setColumnWidth(3, 20);
    ui->tb_Users->setColumnWidth(4, 100);
    ui->tb_Users->setColumnWidth(5, 180);
  }
  else
  {
    qDebug() << "Error: can't open database.";
    exit(0);
  }

  connect(ui->btn_addUser, SIGNAL(clicked(bool)), this, SLOT(btn_addUser()));
  connect(ui->btn_updateUsers, SIGNAL(clicked(bool)), this, SLOT(btn_updateUsers()));
  connect(ui->btn_deleteUser, SIGNAL(clicked(bool)), this, SLOT(btn_deleteUser()));
}

zxMain::~zxMain()
{
  delete m_tbModel;

  if (m_db.isOpen())
  {
    m_db.close();
  }

  delete m_qu;
  delete ui;
}

bool  zxMain::createConnection()
{
  m_db = QSqlDatabase::addDatabase("QSQLITE");
  m_db.setDatabaseName("mydb");

  // m_db.setConnectOptions();
  if (!m_db.open())
  {
    qDebug() << "An error on opening database : " << m_db.lastError();

    return false;
  }

  return true;
}

void  zxMain::createTable()
{
  if (!m_db.isOpen())
  {
    return;
  }

  if (!m_qu->exec("CREATE TABLE IF NOT EXISTS Users"
                  "(id integer PRIMARY KEY AUTOINCREMENT,"
                  "fname varchar(32),lname varchar(32),age int,"
                  "phone varchar(12),address varchar(128) );"))
  {
    qDebug() << "createTable:error :" << m_qu->lastError();
  }
}

bool  zxMain::addUser(QString fname, QString lname, int age, QString phone, QString address)
{
  if (!m_qu->exec("insert into Users(fname,lname,age,phone,address) "
                  "values('" + fname + "', '" + lname + "', " + QString::number(age) + ", '" + phone + "', '" + address + "')"))
  {
    qDebug() << "userAdded:error :" << m_qu->lastError();

    return false;
  }

  return true;
}

bool  zxMain::updateUser(int id, QString fname, QString lname, int age, QString phone, QString address)
{
  if (!m_qu->exec("update Users "
                  "set fname= '" + fname + "', lname ='" + lname + "', age=" + QString::number(age) + ", phone='" + phone + "'" + ", address='" + address + "' "
                                                                                                                                                            "where id=" + QString::number(id)))
  {
    qDebug() << "updateUser: error :" << m_qu->lastError();

    return false;
  }

  return true;
}

bool  zxMain::deleteUser(int id)
{
  if (!m_qu->exec("DELETE FROM Users "
                  "WHERE id = " + QString::number(id) + ";"))
  {
    qDebug() << "deleteUser: error:" << m_qu->lastError();

    return false;
  }

  return true;
}

void  zxMain::clearForm()
{
  ui->le_firstName->clear();
  ui->le_lastName->clear();
  ui->le_phone->clear();
  ui->le_address->clear();
}

void  zxMain::btn_addUser()
{
  if (ui->le_firstName->text().isEmpty() || ui->le_lastName->text().isEmpty())
  {
    QMessageBox::warning(this, "خطا", "پر کردن فیلدهای نام و نام خانوادگی الزامی است. ");

    return;
  }

  if (addUser(ui->le_firstName->text(),
              ui->le_lastName->text(),
              ui->sb_age->value(),
              ui->le_phone->text(),
              ui->le_address->text()))
  {
    qDebug() << "added!";
    m_tbModel->select();
    ui->tb_Users->selectRow(m_tbModel->rowCount() - 1);
    clearForm();
  }
}

void  zxMain::btn_updateUsers()
{
  m_tbModel->submitAll();
}

void  zxMain::btn_deleteUser()
{
  int                          id     = m_tbModel->index(ui->tb_Users->currentIndex().row(), 0).data().toInt();
  QMessageBox::StandardButton  answer = QMessageBox::question(this, "هشدار",
                                                              " آیا میخواهید مشخصات کاربر  ID: " + QString::number(id) + " حذف کنید؟ ");

  if (answer == QMessageBox::Yes)
  {
    if (deleteUser(id))
    {
      m_tbModel->select();
      qDebug() << "remove id: " << id << " successfully.";
    }
  }
}

void  zxMain::on_pushButton_clicked()
{
  mmDial->exec();
  mmDial->children();
}
